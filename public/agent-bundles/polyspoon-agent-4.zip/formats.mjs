// Polyspoon formats module, generated from src/formats by scripts/agent-bundle.ts. Apache-2.0.

// src/formats/gltf-read.ts
var identity = () => Float64Array.of(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1);
function multiply(a, b) {
  const out = new Float64Array(16);
  for (let c = 0; c < 4; c++) for (let r = 0; r < 4; r++) {
    let sum = 0;
    for (let k = 0; k < 4; k++) sum += a[k * 4 + r] * b[c * 4 + k];
    out[c * 4 + r] = sum;
  }
  return out;
}
function compose(t = [0, 0, 0], q = [0, 0, 0, 1], s = [1, 1, 1]) {
  const [x, y, z, w] = q, [sx, sy, sz] = s;
  return Float64Array.of((1 - 2 * (y * y + z * z)) * sx, 2 * (x * y + z * w) * sx, 2 * (x * z - y * w) * sx, 0, 2 * (x * y - z * w) * sy, (1 - 2 * (x * x + z * z)) * sy, 2 * (y * z + x * w) * sy, 0, 2 * (x * z + y * w) * sz, 2 * (y * z - x * w) * sz, (1 - 2 * (x * x + y * y)) * sz, 0, t[0], t[1], t[2], 1);
}
function normalMatrix(m) {
  const a = m[0], b = m[1], c = m[2], d = m[4], e = m[5], f = m[6], g = m[8], h = m[9], i = m[10], det = a * (e * i - f * h) - d * (b * i - c * h) + g * (b * f - c * e) || 1;
  return [[(e * i - f * h) / det, (c * h - b * i) / det, (b * f - c * e) / det], [(f * g - d * i) / det, (a * i - c * g) / det, (c * d - a * f) / det], [(d * h - e * g) / det, (b * g - a * h) / det, (a * e - b * d) / det]];
}
function parseGlb(input) {
  const view = new DataView(input.buffer, input.byteOffset, input.byteLength);
  if (input.byteLength < 20 || view.getUint32(0, true) !== 1179937895 || view.getUint32(4, true) !== 2) throw Error("glb_invalid");
  let offset = 12, json = null, bin = new Uint8Array(0);
  while (offset + 8 <= input.byteLength) {
    const length = view.getUint32(offset, true), type = view.getUint32(offset + 4, true);
    if (offset + 8 + length > input.byteLength) throw Error("glb_truncated");
    const chunk = input.subarray(offset + 8, offset + 8 + length);
    if (type === 1313821514) json = JSON.parse(new TextDecoder().decode(chunk));
    else if (type === 5130562) bin = chunk;
    offset += 8 + length;
  }
  if (!json) throw Error("glb_invalid");
  return { json, bin };
}
var sizes = { SCALAR: 1, VEC2: 2, VEC3: 3, VEC4: 4, MAT2: 4, MAT3: 9, MAT4: 16 };
var componentBytes = { 5120: 1, 5121: 1, 5122: 2, 5123: 2, 5125: 4, 5126: 4 };
function accessor(json, bin, index) {
  const a = json.accessors?.[index];
  if (!a) throw Error("glb_accessor_missing");
  if (a.sparse) throw Error("glb_sparse_unsupported");
  const size = sizes[a.type], width = componentBytes[a.componentType], count = a.count;
  if (!size || !width) throw Error("glb_accessor_type");
  if (!Number.isInteger(count) || count < 0) throw Error("glb_accessor_count");
  const values = new Float64Array(count * size);
  if (a.bufferView === void 0) return { values, size };
  const bv = json.bufferViews?.[a.bufferView];
  if (!bv) throw Error("glb_buffer_view_missing");
  if ((bv.buffer ?? 0) !== 0) throw Error("glb_external_buffer");
  const stride = bv.byteStride || width * size, base = (bv.byteOffset ?? 0) + (a.byteOffset ?? 0), view = new DataView(bin.buffer, bin.byteOffset, bin.byteLength);
  if (count && base + (count - 1) * stride + size * width > bin.byteLength) throw Error("glb_accessor_out_of_range");
  const read = (o) => {
    switch (a.componentType) {
      case 5126:
        return view.getFloat32(o, true);
      case 5125:
        return view.getUint32(o, true);
      case 5123:
        return a.normalized ? view.getUint16(o, true) / 65535 : view.getUint16(o, true);
      case 5121:
        return a.normalized ? view.getUint8(o) / 255 : view.getUint8(o);
      case 5122:
        return a.normalized ? Math.max(view.getInt16(o, true) / 32767, -1) : view.getInt16(o, true);
      case 5120:
        return a.normalized ? Math.max(view.getInt8(o) / 127, -1) : view.getInt8(o);
      default:
        throw Error("glb_component_type");
    }
  };
  for (let i = 0; i < count; i++) for (let c = 0; c < size; c++) values[i * size + c] = read(base + i * stride + c * width);
  return { values, size };
}
function readGlb(input) {
  const { json, bin } = parseGlb(input), meshes = [];
  const materials = (json.materials ?? []).map((m, i) => ({ name: String(m.name || "material_" + i), color: m.pbrMetallicRoughness?.baseColorFactor ?? [1, 1, 1, 1], metallic: m.pbrMetallicRoughness?.metallicFactor ?? 1, roughness: m.pbrMetallicRoughness?.roughnessFactor ?? 1, doubleSided: !!m.doubleSided }));
  const sourceMaterials = materials.length;
  let fallback = -1;
  const fallbackMaterial = () => {
    if (fallback < 0) {
      fallback = materials.length;
      materials.push({ name: "default", color: [0.8, 0.8, 0.8, 1], metallic: 0, roughness: 1, doubleSided: false });
    }
    return fallback;
  };
  const scene = json.scenes?.[json.scene ?? 0], used = /* @__PURE__ */ new Map([["Materials", 1]]), visiting = /* @__PURE__ */ new Set();
  const visit = (index, parent) => {
    const node2 = json.nodes?.[index];
    if (!node2) throw Error("glb_node_missing");
    if (visiting.has(index)) throw Error("glb_node_cycle");
    visiting.add(index);
    const local = node2.matrix ? Float64Array.from(node2.matrix) : compose(node2.translation, node2.rotation, node2.scale), world = multiply(parent, local);
    if (node2.mesh !== void 0) {
      const mesh = json.meshes?.[node2.mesh];
      if (!mesh) throw Error("glb_mesh_missing");
      const n = normalMatrix(world);
      mesh.primitives.forEach((p, pi) => {
        if ((p.mode ?? 4) !== 4 || p.attributes.POSITION === void 0) return;
        const position = accessor(json, bin, p.attributes.POSITION);
        if (position.size !== 3) throw Error("glb_position_type");
        const pos = position.values, count = pos.length / 3, positions = new Float64Array(count * 3);
        for (let v = 0; v < count; v++) {
          const x = pos[v * 3], y = pos[v * 3 + 1], z = pos[v * 3 + 2];
          for (let r = 0; r < 3; r++) positions[v * 3 + r] = world[r] * x + world[4 + r] * y + world[8 + r] * z + world[12 + r];
        }
        let normals = null;
        if (p.attributes.NORMAL !== void 0) {
          const src = accessor(json, bin, p.attributes.NORMAL).values;
          normals = new Float64Array(count * 3);
          for (let v = 0; v < count; v++) {
            const x = src[v * 3], y = src[v * 3 + 1], z = src[v * 3 + 2];
            let nx = n[0][0] * x + n[0][1] * y + n[0][2] * z, ny = n[1][0] * x + n[1][1] * y + n[1][2] * z, nz = n[2][0] * x + n[2][1] * y + n[2][2] * z;
            const l = Math.hypot(nx, ny, nz) || 1;
            normals[v * 3] = nx / l;
            normals[v * 3 + 1] = ny / l;
            normals[v * 3 + 2] = nz / l;
          }
        }
        const uvs = p.attributes.TEXCOORD_0 !== void 0 ? accessor(json, bin, p.attributes.TEXCOORD_0).values : null;
        let indices;
        if (p.indices !== void 0) {
          indices = Uint32Array.from(accessor(json, bin, p.indices).values);
          if (indices.length % 3 || indices.some((i) => i >= count)) throw Error("glb_indices_invalid");
        } else indices = Uint32Array.from({ length: count }, (_, i) => i);
        const determinant = world[0] * (world[5] * world[10] - world[6] * world[9]) - world[4] * (world[1] * world[10] - world[2] * world[9]) + world[8] * (world[1] * world[6] - world[2] * world[5]);
        if (determinant < 0) for (let t = 0; t < indices.length; t += 3) {
          const s = indices[t + 1];
          indices[t + 1] = indices[t + 2];
          indices[t + 2] = s;
        }
        let base = String(node2.name || mesh.name || "mesh").replace(/[^A-Za-z0-9_]/g, "_") || "mesh";
        if (/^[0-9]/.test(base)) base = "m_" + base;
        if (mesh.primitives.length > 1) base += "_" + pi;
        const seen = used.get(base) ?? 0;
        used.set(base, seen + 1);
        meshes.push({ name: seen ? base + "_" + seen : base, positions, normals, uvs, indices, material: Number.isInteger(p.material) && p.material >= 0 && p.material < sourceMaterials ? p.material : fallbackMaterial() });
      });
    }
    for (const child of node2.children ?? []) visit(child, world);
    visiting.delete(index);
  };
  for (const root of scene?.nodes ?? []) visit(root, identity());
  return { meshes, materials, skinned: !!json.skins?.length, animated: !!json.animations?.length, textured: !!json.textures?.length };
}
function bounds(scene) {
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const m of scene.meshes) for (let i = 0; i < m.positions.length; i += 3) for (let c = 0; c < 3; c++) {
    min[c] = Math.min(min[c], m.positions[i + c]);
    max[c] = Math.max(max[c], m.positions[i + c]);
  }
  return { min, max };
}

// src/formats/writers.ts
var encoder = new TextEncoder();
var num = (value) => {
  const r = Math.round(value * 1e6) / 1e6;
  return Object.is(r, -0) ? "0" : String(r);
};
var safe = (name) => name.replace(/[^A-Za-z0-9_]/g, "_") || "model";
function toObj(scene, name = "model") {
  const base = safe(name), obj = ["# Polyspoon OBJ export. Units: meters. Up: +Y. Right handed.", "mtllib " + base + ".mtl"], mtl = ["# Polyspoon MTL export"];
  let vOffset = 1, tOffset = 1, nOffset = 1;
  for (const m of scene.meshes) {
    obj.push("o " + m.name);
    const count = m.positions.length / 3;
    for (let i = 0; i < count; i++) obj.push("v " + num(m.positions[i * 3]) + " " + num(m.positions[i * 3 + 1]) + " " + num(m.positions[i * 3 + 2]));
    if (m.uvs) for (let i = 0; i < count; i++) obj.push("vt " + num(m.uvs[i * 2]) + " " + num(1 - m.uvs[i * 2 + 1]));
    if (m.normals) for (let i = 0; i < count; i++) obj.push("vn " + num(m.normals[i * 3]) + " " + num(m.normals[i * 3 + 1]) + " " + num(m.normals[i * 3 + 2]));
    obj.push("usemtl " + safe(scene.materials[m.material].name) + "_" + m.material);
    const ref = (i) => String(vOffset + i) + (m.uvs || m.normals ? "/" + (m.uvs ? tOffset + i : "") + (m.normals ? "/" + (nOffset + i) : "") : "");
    for (let t = 0; t < m.indices.length; t += 3) obj.push("f " + ref(m.indices[t]) + " " + ref(m.indices[t + 1]) + " " + ref(m.indices[t + 2]));
    vOffset += count;
    if (m.uvs) tOffset += count;
    if (m.normals) nOffset += count;
  }
  scene.materials.forEach((mat, i) => {
    const [r, g, b, a] = mat.color, ks = num(0.04 + 0.48 * mat.metallic);
    mtl.push("newmtl " + safe(mat.name) + "_" + i, "Kd " + num(r) + " " + num(g) + " " + num(b), "Ka 0 0 0", "Ks " + ks + " " + ks + " " + ks, "Ns " + num(Math.max(1, (1 - mat.roughness) * 1e3)), "d " + num(a), "illum 2", "Pr " + num(mat.roughness), "Pm " + num(mat.metallic), "");
  });
  return { obj: obj.join("\n") + "\n", mtl: mtl.join("\n") + "\n", base };
}
function toObjZip(scene, name = "model") {
  const { obj, mtl, base } = toObj(scene, name);
  return storedZip({ [base + ".obj"]: encoder.encode(obj), [base + ".mtl"]: encoder.encode(mtl) });
}
var tuple = (values, size, map = (v) => v) => {
  const out = [];
  for (let i = 0; i < values.length; i += size) {
    const p = [];
    for (let c = 0; c < size; c++) p.push(num(map(values[i + c], c)));
    out.push("(" + p.join(", ") + ")");
  }
  return "[" + out.join(", ") + "]";
};
function toUsda(scene, name = "model") {
  const root = safe(name).replace(/^([0-9])/, "_$1"), lines = ["#usda 1.0", "(", "    customLayerData = {", '        string creator = "Polyspoon"', "    }", '    defaultPrim = "' + root + '"', "    metersPerUnit = 1", '    upAxis = "Y"', ")", "", 'def Xform "' + root + '" (', '    kind = "component"', ")", "{", '    def Scope "Materials"', "    {"];
  scene.materials.forEach((mat, i) => {
    const id = "material_" + i, [r, g, b, a] = mat.color;
    lines.push('        def Material "' + id + '"', "        {", "            token outputs:surface.connect = </" + root + "/Materials/" + id + "/PreviewSurface.outputs:surface>", '            def Shader "PreviewSurface"', "            {", '                uniform token info:id = "UsdPreviewSurface"', "                color3f inputs:diffuseColor = (" + num(r) + ", " + num(g) + ", " + num(b) + ")", "                float inputs:metallic = " + num(mat.metallic), "                float inputs:roughness = " + num(mat.roughness), "                float inputs:opacity = " + num(a), "                token outputs:surface", "            }", "        }");
  });
  lines.push("    }");
  for (const m of scene.meshes) {
    lines.push("", '    def Mesh "' + m.name + '" (', '        prepend apiSchemas = ["MaterialBindingAPI"]', "    )", "    {", "        uniform bool doubleSided = " + (scene.materials[m.material].doubleSided ? "1" : "0"), "        int[] faceVertexCounts = [" + new Array(m.indices.length / 3).fill(3).join(", ") + "]", "        int[] faceVertexIndices = [" + Array.from(m.indices).join(", ") + "]", '        uniform token orientation = "rightHanded"', "        point3f[] points = " + tuple(m.positions, 3));
    if (m.normals) lines.push("        normal3f[] normals = " + tuple(m.normals, 3) + " (", '            interpolation = "vertex"', "        )");
    if (m.uvs) lines.push("        texCoord2f[] primvars:st = " + tuple(m.uvs, 2, (v, c) => c === 1 ? 1 - v : v) + " (", '            interpolation = "vertex"', "        )");
    lines.push("        rel material:binding = </" + root + "/Materials/material_" + m.material + ">", '        uniform token subdivisionScheme = "none"', "    }");
  }
  lines.push("}", "");
  return lines.join("\n");
}
function crc32(bytes) {
  let crc = 4294967295;
  for (const byte of bytes) {
    crc ^= byte;
    for (let bit = 0; bit < 8; bit++) crc = crc >>> 1 ^ (crc & 1 ? 3988292384 : 0);
  }
  return (crc ^ 4294967295) >>> 0;
}
function storedZip(files, align = 1) {
  const locals = [], central = [];
  let offset = 0;
  for (const [name, data] of Object.entries(files)) {
    const filename = encoder.encode(name), crc = crc32(data), fixed = 30 + filename.length, pad = align > 1 ? (align - (offset + fixed + 4) % align) % align : 0, extraLength = 4 + pad, header = new Uint8Array(fixed + extraLength), view2 = new DataView(header.buffer);
    view2.setUint32(0, 67324752, true);
    view2.setUint16(4, 20, true);
    view2.setUint32(14, crc, true);
    view2.setUint32(18, data.length, true);
    view2.setUint32(22, data.length, true);
    view2.setUint16(26, filename.length, true);
    view2.setUint16(28, extraLength, true);
    header.set(filename, 30);
    view2.setUint16(fixed, 6534, true);
    view2.setUint16(fixed + 2, pad, true);
    locals.push(header, data);
    const record = new Uint8Array(46 + filename.length), entry = new DataView(record.buffer);
    entry.setUint32(0, 33639248, true);
    entry.setUint16(4, 20, true);
    entry.setUint16(6, 20, true);
    entry.setUint32(16, crc, true);
    entry.setUint32(20, data.length, true);
    entry.setUint32(24, data.length, true);
    entry.setUint16(28, filename.length, true);
    entry.setUint32(42, offset, true);
    record.set(filename, 46);
    central.push(record);
    offset += header.length + data.length;
  }
  const size = central.reduce((s, r) => s + r.length, 0), end = new Uint8Array(22), view = new DataView(end.buffer);
  view.setUint32(0, 101010256, true);
  view.setUint16(8, central.length, true);
  view.setUint16(10, central.length, true);
  view.setUint32(12, size, true);
  view.setUint32(16, offset, true);
  const out = new Uint8Array(offset + size + 22);
  let cursor = 0;
  for (const part of [...locals, ...central, end]) {
    out.set(part, cursor);
    cursor += part.length;
  }
  return out;
}
function toUsdz(scene, name = "model") {
  return storedZip({ [safe(name) + ".usda"]: encoder.encode(toUsda(scene, name)) }, 64);
}
var I = (v) => ({ t: "I", v });
var L = (v) => ({ t: "L", v: BigInt(v) });
var D = (v) => ({ t: "D", v });
var S = (v) => ({ t: "S", v });
var C = (v) => ({ t: "C", v });
var Da = (v) => ({ t: "d", v });
var Ia = (v) => ({ t: "i", v });
var node = (name, props = [], children = []) => ({ name, props, children });
var P = (name, type, label, flags, ...values) => node("P", [S(name), S(type), S(label), S(flags), ...values]);
function propBytes(p) {
  switch (p.t) {
    case "I": {
      const b = new Uint8Array(5), v = new DataView(b.buffer);
      b[0] = 73;
      v.setInt32(1, p.v, true);
      return b;
    }
    case "L": {
      const b = new Uint8Array(9), v = new DataView(b.buffer);
      b[0] = 76;
      v.setBigInt64(1, p.v, true);
      return b;
    }
    case "D": {
      const b = new Uint8Array(9), v = new DataView(b.buffer);
      b[0] = 68;
      v.setFloat64(1, p.v, true);
      return b;
    }
    case "C":
      return Uint8Array.of(67, p.v ? 1 : 0);
    case "S": {
      const s = encoder.encode(p.v), b = new Uint8Array(5 + s.length), v = new DataView(b.buffer);
      b[0] = 83;
      v.setUint32(1, s.length, true);
      b.set(s, 5);
      return b;
    }
    case "d":
    case "i": {
      const width = p.t === "d" ? 8 : 4, n = p.v.length, b = new Uint8Array(13 + n * width), v = new DataView(b.buffer);
      b[0] = p.t.charCodeAt(0);
      v.setUint32(1, n, true);
      v.setUint32(5, 0, true);
      v.setUint32(9, n * width, true);
      for (let i = 0; i < n; i++) {
        if (p.t === "d") v.setFloat64(13 + i * 8, p.v[i], true);
        else v.setInt32(13 + i * 4, p.v[i], true);
      }
      return b;
    }
  }
}
function encodeNode(n, start) {
  const name = encoder.encode(n.name), props = n.props.map(propBytes), propLength = props.reduce((s, b) => s + b.length, 0), headerLength = 13 + name.length;
  const parts = [];
  let cursor = start + headerLength + propLength;
  const childParts = [];
  for (const child of n.children) {
    const encoded = encodeNode(child, cursor);
    for (const e of encoded) {
      childParts.push(e);
      cursor += e.length;
    }
  }
  if (n.children.length || !n.props.length) {
    childParts.push(new Uint8Array(13));
    cursor += 13;
  }
  const header = new Uint8Array(headerLength), view = new DataView(header.buffer);
  view.setUint32(0, cursor, true);
  view.setUint32(4, n.props.length, true);
  view.setUint32(8, propLength, true);
  header[12] = name.length;
  header.set(name, 13);
  parts.push(header, ...props, ...childParts);
  return parts;
}
function fbxFile(nodes) {
  const head = new Uint8Array(27);
  head.set(encoder.encode("Kaydara FBX Binary  "), 0);
  head[20] = 0;
  head[21] = 26;
  head[22] = 0;
  new DataView(head.buffer).setUint32(23, 7400, true);
  const parts = [head];
  let cursor = 27;
  for (const n of nodes) for (const e of encodeNode(n, cursor)) {
    parts.push(e);
    cursor += e.length;
  }
  parts.push(new Uint8Array(13));
  cursor += 13;
  const footerId = Uint8Array.of(250, 188, 171, 9, 208, 200, 212, 102, 177, 118, 251, 131, 28, 247, 38, 126);
  parts.push(footerId, new Uint8Array(4));
  cursor += 20;
  const pad = (16 - cursor % 16) % 16;
  parts.push(new Uint8Array(pad));
  const version = new Uint8Array(4);
  new DataView(version.buffer).setUint32(0, 7400, true);
  parts.push(version, new Uint8Array(120), Uint8Array.of(248, 90, 140, 106, 222, 245, 217, 126, 236, 233, 12, 227, 117, 143, 41, 11));
  const total = parts.reduce((s, p) => s + p.length, 0), out = new Uint8Array(total);
  let o = 0;
  for (const p of parts) {
    out.set(p, o);
    o += p.length;
  }
  return out;
}
function geometryNode(id, m) {
  const polygon = new Int32Array(m.indices.length);
  for (let t = 0; t < m.indices.length; t += 3) {
    polygon[t] = m.indices[t];
    polygon[t + 1] = m.indices[t + 1];
    polygon[t + 2] = ~m.indices[t + 2];
  }
  const children = [node("GeometryVersion", [I(124)]), node("Vertices", [Da(m.positions)]), node("PolygonVertexIndex", [Ia(polygon)])], layer = [node("Version", [I(100)])];
  if (m.normals) {
    const normals = new Float64Array(m.indices.length * 3);
    for (let k = 0; k < m.indices.length; k++) for (let c = 0; c < 3; c++) normals[k * 3 + c] = m.normals[m.indices[k] * 3 + c];
    children.push(node("LayerElementNormal", [I(0)], [node("Version", [I(101)]), node("Name", [S("")]), node("MappingInformationType", [S("ByPolygonVertex")]), node("ReferenceInformationType", [S("Direct")]), node("Normals", [Da(normals)])]));
    layer.push(node("LayerElement", [], [node("Type", [S("LayerElementNormal")]), node("TypedIndex", [I(0)])]));
  }
  if (m.uvs) {
    const uv = new Float64Array(m.uvs.length);
    for (let i = 0; i < m.uvs.length; i += 2) {
      uv[i] = m.uvs[i];
      uv[i + 1] = 1 - m.uvs[i + 1];
    }
    children.push(node("LayerElementUV", [I(0)], [node("Version", [I(101)]), node("Name", [S("UVMap")]), node("MappingInformationType", [S("ByPolygonVertex")]), node("ReferenceInformationType", [S("IndexToDirect")]), node("UV", [Da(uv)]), node("UVIndex", [Ia(m.indices)])]));
    layer.push(node("LayerElement", [], [node("Type", [S("LayerElementUV")]), node("TypedIndex", [I(0)])]));
  }
  children.push(node("LayerElementMaterial", [I(0)], [node("Version", [I(101)]), node("Name", [S("")]), node("MappingInformationType", [S("AllSame")]), node("ReferenceInformationType", [S("IndexToDirect")]), node("Materials", [Ia([0])])]));
  layer.push(node("LayerElement", [], [node("Type", [S("LayerElementMaterial")]), node("TypedIndex", [I(0)])]));
  children.push(node("Layer", [I(0)], layer));
  return node("Geometry", [L(id), S(m.name + "\0Geometry"), S("Mesh")], children);
}
function toFbx(scene) {
  let next = 1e6;
  const objects = [], connections = [], materialIds = /* @__PURE__ */ new Map();
  const settings = node("GlobalSettings", [], [node("Version", [I(1e3)]), node("Properties70", [], [P("UpAxis", "int", "Integer", "", I(1)), P("UpAxisSign", "int", "Integer", "", I(1)), P("FrontAxis", "int", "Integer", "", I(2)), P("FrontAxisSign", "int", "Integer", "", I(1)), P("CoordAxis", "int", "Integer", "", I(0)), P("CoordAxisSign", "int", "Integer", "", I(1)), P("OriginalUpAxis", "int", "Integer", "", I(1)), P("OriginalUpAxisSign", "int", "Integer", "", I(1)), P("UnitScaleFactor", "double", "Number", "", D(100)), P("OriginalUnitScaleFactor", "double", "Number", "", D(100))])]);
  scene.materials.forEach((mat, i) => {
    if (!scene.meshes.some((m) => m.material === i)) return;
    const id = next++;
    materialIds.set(i, id);
    const [r, g, b, a] = mat.color;
    objects.push(node("Material", [L(id), S(mat.name + "\0Material"), S("")], [node("Version", [I(102)]), node("ShadingModel", [S("phong")]), node("MultiLayer", [I(0)]), node("Properties70", [], [P("DiffuseColor", "Color", "", "A", D(r), D(g), D(b)), P("Diffuse", "Vector3D", "Vector", "", D(r), D(g), D(b)), P("Opacity", "double", "Number", "", D(a)), P("TransparencyFactor", "Number", "", "A", D(1 - a)), P("Shininess", "double", "Number", "", D(Math.max(2, (1 - mat.roughness) * 100)))])]));
  });
  for (const m of scene.meshes) {
    const g = next++, model = next++;
    objects.push(geometryNode(g, m), node("Model", [L(model), S(m.name + "\0Model"), S("Mesh")], [node("Version", [I(232)]), node("Properties70", [], [P("Lcl Translation", "Lcl Translation", "", "A", D(0), D(0), D(0)), P("Lcl Rotation", "Lcl Rotation", "", "A", D(0), D(0), D(0)), P("Lcl Scaling", "Lcl Scaling", "", "A", D(1), D(1), D(1))]), node("Shading", [C(true)]), node("Culling", [S("CullingOff")])]));
    connections.push(node("C", [S("OO"), L(model), L(0)]), node("C", [S("OO"), L(g), L(model)]), node("C", [S("OO"), L(materialIds.get(m.material)), L(model)]));
  }
  const header = node("FBXHeaderExtension", [], [node("FBXHeaderVersion", [I(1003)]), node("FBXVersion", [I(7400)]), node("Creator", [S("Polyspoon")])]);
  const definitions = node("Definitions", [], [node("Version", [I(100)]), node("Count", [I(1 + objects.length)]), node("ObjectType", [S("GlobalSettings")], [node("Count", [I(1)])]), node("ObjectType", [S("Geometry")], [node("Count", [I(scene.meshes.length)])]), node("ObjectType", [S("Model")], [node("Count", [I(scene.meshes.length)])]), node("ObjectType", [S("Material")], [node("Count", [I(materialIds.size)])])]);
  return fbxFile([header, node("FileId", [{ t: "S", v: "" }]), node("CreationTime", [S("1970-01-01 00:00:00:000")]), node("Creator", [S("Polyspoon")]), settings, node("Documents", [], [node("Count", [I(0)])]), node("References"), definitions, node("Objects", [], objects), node("Connections", [], connections)]);
}

// src/formats/index.ts
var exportFormats = {
  obj: { extension: ".obj.zip", mediaType: "application/zip", label: "OBJ + MTL (zip)" },
  fbx: { extension: ".fbx", mediaType: "application/octet-stream", label: "FBX 7.4 binary" },
  usdz: { extension: ".usdz", mediaType: "model/vnd.usdz+zip", label: "USDZ" }
};
function convertGlb(glb, format, name = "model") {
  const scene = readGlb(glb);
  if (!scene.meshes.length) throw Error("glb_no_meshes");
  return format === "obj" ? toObjZip(scene, name) : format === "fbx" ? toFbx(scene) : toUsdz(scene, name);
}

// src/formats/model-controls.json
var model_controls_default = {
  formatVersion: 1,
  kind: "polyspoon.recipe-controls",
  units: {
    length: "m",
    up: "+Y",
    handedness: "right"
  },
  families: {
    bench: {
      title: "Slatted bench",
      version: "1.1.0",
      description: "An original contributor example with supported seat boards and an optional backrest.",
      defaults: {
        width: 1.6,
        depth: 0.45,
        seatHeight: 0.45,
        slatCount: 4,
        backrest: true,
        backHeight: 0.35,
        colorway: "oak",
        "color.wood": "#b88654",
        "color.frame": "#604532"
      },
      presets: [
        {
          id: "garden",
          name: "Garden bench",
          description: "Four oak seat boards with a backrest.",
          parameters: {}
        },
        {
          id: "low-seat",
          name: "Low seat",
          description: "A short three-board seat without a backrest.",
          parameters: {
            width: 1.1,
            seatHeight: 0.35,
            slatCount: 3,
            backrest: false
          }
        },
        {
          id: "park",
          name: "Park bench",
          description: "A wider painted bench with a taller back.",
          parameters: {
            width: 2.2,
            depth: 0.55,
            slatCount: 5,
            backHeight: 0.48,
            colorway: "painted"
          }
        }
      ],
      palettes: [
        {
          id: "oak",
          label: "Oak",
          colors: [
            "#b88654",
            "#604532"
          ]
        },
        {
          id: "painted",
          label: "Painted",
          colors: [
            "#8ca58b",
            "#384a42"
          ]
        }
      ],
      controls: [
        {
          key: "width",
          label: "Seat width",
          kind: "range",
          group: "shape",
          min: 0.9,
          max: 2.4,
          step: 0.05,
          default: 1.6,
          hint: "Outside seat width.",
          affects: [
            "geometry"
          ],
          targets: [
            "seat-slat",
            "apron",
            "leg",
            "seat-support",
            "back-post",
            "back-slat"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "depth",
          label: "Seat depth",
          kind: "range",
          group: "shape",
          min: 0.32,
          max: 0.65,
          step: 0.01,
          default: 0.45,
          hint: "Outside seat depth.",
          affects: [
            "geometry"
          ],
          targets: [
            "seat-slat",
            "leg",
            "seat-support",
            "apron",
            "back-post",
            "back-slat"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "seatHeight",
          label: "Seat height",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.55,
          step: 0.01,
          default: 0.45,
          hint: "Ground to seat top.",
          affects: [
            "geometry"
          ],
          targets: [
            "seat-slat",
            "leg",
            "apron",
            "seat-support",
            "back-post",
            "back-slat"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "slatCount",
          label: "Seat slats",
          kind: "integer",
          group: "construction",
          min: 3,
          max: 6,
          step: 1,
          default: 4,
          hint: "Changes the number and width of seat boards.",
          affects: [
            "topology"
          ],
          targets: [
            "seat-slat"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "backrest",
          label: "Backrest",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Adds two supported back boards.",
          affects: [
            "topology"
          ],
          targets: [
            "back-post",
            "back-slat"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "backHeight",
          label: "Back height",
          kind: "range",
          group: "shape",
          min: 0.25,
          max: 0.55,
          step: 0.01,
          default: 0.35,
          hint: "Seat top to back top. Used only with a backrest.",
          affects: [
            "geometry"
          ],
          targets: [
            "back-post",
            "back-slat"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "oak",
          options: [
            {
              value: "oak",
              label: "Oak"
            },
            {
              value: "painted",
              label: "Painted"
            }
          ],
          hint: "Starting colors; individual roles can override them.",
          affects: [
            "material"
          ],
          targets: [
            "wood",
            "frame"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.wood",
          label: "Boards",
          kind: "color",
          group: "colors",
          default: "#b88654",
          role: "wood",
          hint: "Seat and back boards.",
          affects: [
            "material"
          ],
          targets: [
            "seat-slat",
            "back-slat"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.frame",
          label: "Frame",
          kind: "color",
          group: "colors",
          default: "#604532",
          role: "frame",
          hint: "Legs, supports and aprons.",
          affects: [
            "material"
          ],
          targets: [
            "leg",
            "apron",
            "seat-support",
            "back-post"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    boulder: {
      title: "Field boulder",
      version: "0.6.0",
      description: "A grounded faceted stone.",
      defaults: {
        width: 1.6,
        height: 0.95,
        depth: 1.2,
        lean: 0.08,
        form: "field",
        seed: 17,
        angularity: 0.7,
        crest: -0.12,
        shoulderHeight: 0.66,
        moss: "top",
        mossCoverage: 0.48,
        facetGrade: 1,
        burialDepth: 0.12,
        colorway: "forest",
        "color.stone": "#7d8279",
        "color.moss": "#66724b"
      },
      presets: [
        {
          id: "field",
          name: "Buried mossy field stone",
          description: "Buried mossy field stone proportions",
          parameters: {
            form: "field",
            facetGrade: 0,
            burialDepth: 0.25,
            mossCoverage: 0.75,
            angularity: 0.45
          }
        },
        {
          id: "slab",
          name: "Low weathered shelf",
          description: "Low weathered shelf proportions",
          parameters: {
            width: 2.6,
            height: 0.65,
            depth: 1.8,
            form: "slab",
            angularity: 0.6,
            crest: -0.24,
            shoulderHeight: 0.48,
            moss: "top",
            mossCoverage: 0.75,
            burialDepth: 0.08
          }
        },
        {
          id: "standing",
          name: "Dry standing fracture",
          description: "Dry standing fracture proportions",
          parameters: {
            width: 1.4,
            height: 1.7,
            depth: 1.4,
            form: "standing",
            angularity: 0.95,
            crest: 0.16,
            shoulderHeight: 0.77,
            lean: 0.16,
            moss: "none",
            burialDepth: 0
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#7d8279"
          ]
        },
        {
          id: "harbor",
          label: "Harbor",
          colors: [
            "#778487"
          ]
        },
        {
          id: "ember",
          label: "Ember",
          colors: [
            "#928071"
          ]
        }
      ],
      controls: [
        {
          kind: "range",
          key: "width",
          label: "Width scale",
          default: 1.6,
          min: 0.6,
          max: 2.8,
          step: 0.05,
          group: "shape",
          hint: "Scales the authored stone shape across X; final bounds depend on its form.",
          affects: [
            "geometry"
          ],
          targets: [
            "boulder"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "height",
          label: "Height before burial",
          default: 0.95,
          min: 0.35,
          max: 1.8,
          step: 0.05,
          group: "shape",
          hint: "Sets the unburied height; burial reduces the exposed height above ground.",
          affects: [
            "geometry"
          ],
          targets: [
            "boulder"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "depth",
          label: "Depth scale",
          default: 1.2,
          min: 0.5,
          max: 2.4,
          step: 0.05,
          group: "shape",
          hint: "Scales the authored stone shape across Z; final bounds depend on its form.",
          affects: [
            "geometry"
          ],
          targets: [
            "boulder"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "lean",
          label: "Shoulder lean",
          default: 0.08,
          min: -0.18,
          max: 0.18,
          step: 0.01,
          group: "shape",
          ratioBasis: "width",
          hint: "Height must be at most 1.3 \xD7 the smaller of width and depth. Lower height or increase the smaller footprint dimension.",
          affects: [
            "geometry"
          ],
          targets: [
            "boulder"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "form",
          kind: "choice",
          group: "construction",
          label: "Stone form",
          default: "field",
          options: [
            {
              value: "slab",
              label: "Layered slab"
            },
            {
              value: "standing",
              label: "Standing fracture"
            },
            {
              value: "field",
              label: "Field boulder"
            }
          ],
          hint: "Selects a distinct major-plane and shoulder construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "stone-mass"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "seed",
          kind: "integer",
          group: "shape",
          label: "Fracture seed",
          default: 17,
          min: 0,
          max: 65535,
          step: 1,
          hint: "Changes coherent shoulders and fracture planes within the selected form.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "stone-mass"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "angularity",
          label: "Plane angularity",
          kind: "range",
          default: 0.7,
          min: 0.3,
          max: 1,
          step: 0.05,
          ratioBasis: "normalized",
          group: "construction",
          hint: "Higher angularity narrows the clipped corner transition faces; major stone planes remain broad.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "boulder"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "crest",
          label: "Crest bias",
          kind: "range",
          default: -0.12,
          min: -0.28,
          max: 0.24,
          step: 0.02,
          ratioBasis: "normalized",
          group: "construction",
          hint: "Biases the unburied crest shape and upper stone position; burial determines the exposed height.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "boulder"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "shoulderHeight",
          label: "Shoulder height",
          kind: "range",
          default: 0.66,
          min: 0.45,
          max: 0.8,
          step: 0.01,
          ratioBasis: "height",
          group: "construction",
          hint: "Sets shoulder cutting levels in the unburied shape; burial determines the exposed height.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "boulder"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "moss",
          label: "Moss region",
          kind: "choice",
          default: "top",
          options: [
            {
              value: "none",
              label: "None"
            },
            {
              value: "top",
              label: "Top"
            }
          ],
          group: "construction",
          hint: "Adds continuous moss growth across the upper surface and shoulders.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "boulder"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "mossCoverage",
          label: "Moss coverage",
          kind: "range",
          default: 0.48,
          min: 0.2,
          max: 0.8,
          step: 0.05,
          ratioBasis: "normalized",
          group: "construction",
          hint: "Expands continuous moss growth over the upper surface and shoulders.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "boulder"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "integer",
          key: "facetGrade",
          label: "Facet grade",
          default: 1,
          min: 0,
          max: 2,
          step: 1,
          group: "construction",
          hint: "Facet grade adjusts connected construction.",
          affects: [
            "geometry"
          ],
          targets: [
            "facetGrade"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          kind: "range",
          key: "burialDepth",
          label: "Buried fraction",
          default: 0.12,
          min: 0,
          max: 0.4,
          step: 0.05,
          group: "construction",
          hint: "Fraction buried below ground, reducing the exposed height.",
          affects: [
            "geometry"
          ],
          targets: [
            "boulder"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "Forest"
            },
            {
              value: "harbor",
              label: "Harbor"
            },
            {
              value: "ember",
              label: "Ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.stone",
          label: "Stone",
          role: "stone",
          default: "#7d8279",
          group: "colors",
          hint: "Changes only stone color.",
          affects: [
            "material"
          ],
          targets: [
            "stone"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.moss",
          label: "Moss",
          role: "moss",
          default: "#66724b",
          group: "colors",
          hint: "Changes the coherent upper moss region.",
          affects: [
            "material"
          ],
          targets: [
            "moss-region"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    conifer: {
      title: "Wild pine",
      version: "1.1.0",
      description: "Faceted pine with irregular branch tiers and visible connected woody structure.",
      defaults: {
        height: 6,
        crownSpread: 3.8,
        seed: 317,
        tierCount: 8,
        "color.bark": "#70523a",
        "color.needles": "#365c43",
        "color.tips": "#55754c",
        "color.shade": "#284c3c"
      },
      presets: [
        {
          id: "woodland",
          name: "Woodland pine",
          description: "Uneven open crown with exposed branch joints.",
          parameters: {}
        },
        {
          id: "slender",
          name: "Slender pine",
          description: "Tall narrow silhouette with ten close-set tiers.",
          parameters: {
            height: 9,
            crownSpread: 3,
            seed: 901,
            tierCount: 10
          }
        },
        {
          id: "windswept",
          name: "Broad pine",
          description: "Short broad crown with five open tiers.",
          parameters: {
            height: 4.5,
            crownSpread: 4.7,
            seed: 42,
            tierCount: 5
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#70523a",
            "#365c43",
            "#55754c",
            "#284c3c"
          ]
        }
      ],
      controls: [
        {
          key: "height",
          label: "Height",
          kind: "range",
          group: "shape",
          min: 2,
          max: 12,
          step: 0.1,
          default: 6,
          hint: "Ground to highest needle.",
          affects: [
            "geometry"
          ],
          targets: [
            "trunk",
            "branch",
            "foliage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "crownSpread",
          label: "Crown spread",
          kind: "range",
          group: "shape",
          min: 1,
          max: 7,
          step: 0.1,
          default: 3.8,
          hint: "Larger horizontal bounding-box dimension.",
          affects: [
            "geometry"
          ],
          targets: [
            "trunk",
            "branch",
            "foliage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "seed",
          label: "Variation seed",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 65535,
          step: 1,
          default: 317,
          hint: "Repeatable trunk bends, branch spacing and foliage variation.",
          affects: [
            "geometry"
          ],
          targets: [
            "trunk",
            "branch",
            "foliage"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "tierCount",
          label: "Crown tiers",
          kind: "integer",
          group: "construction",
          min: 5,
          max: 10,
          step: 1,
          default: 8,
          hint: "Redistributes five to ten connected branch tiers through the same crown envelope, with fewer branches and smaller lobes toward the leader.",
          affects: [
            "topology",
            "geometry"
          ],
          targets: [
            "branch",
            "foliage"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "color.bark",
          label: "bark",
          kind: "color",
          group: "colors",
          default: "#70523a",
          role: "bark",
          hint: "Opaque faceted bark material.",
          affects: [
            "material"
          ],
          targets: [
            "bark"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.needles",
          label: "needles",
          kind: "color",
          group: "colors",
          default: "#365c43",
          role: "needles",
          hint: "Opaque faceted needles material.",
          affects: [
            "material"
          ],
          targets: [
            "needles"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.tips",
          label: "tips",
          kind: "color",
          group: "colors",
          default: "#55754c",
          role: "tips",
          hint: "Opaque faceted tips material.",
          affects: [
            "material"
          ],
          targets: [
            "tips"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.shade",
          label: "shade",
          kind: "color",
          group: "colors",
          default: "#284c3c",
          role: "shade",
          hint: "Opaque faceted shade material.",
          affects: [
            "material"
          ],
          targets: [
            "shade"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    cottage: {
      title: "Workshop cottage",
      version: "0.6.0",
      description: "A timber workshop with a deep entrance and working bay.",
      defaults: {
        width: 5,
        depth: 4,
        wallHeight: 2.8,
        roofRise: 1.4,
        chimney: true,
        beamWeight: "stout",
        eaveOverhang: 0.4,
        workBay: "right",
        shutters: true,
        roofCharacter: 0.45,
        detail: "inspection",
        roofCover: "thatch",
        roofThickness: 0.24,
        framingStyle: "diagonal",
        windowLayout: "paired",
        bayDepth: 1.65,
        weathering: 0.3,
        timberTone: 0.35,
        toneVariation: 0.06,
        beamSection: 1,
        ridgeSag: 1,
        colorway: "forest",
        "color.plaster": "#e2d6b8",
        "color.roof": "#b7a16b",
        "color.timber": "#49382c",
        "color.wood": "#966c48",
        "color.recess": "#34433e",
        "color.stone": "#7d8279",
        "color.hardware": "#b99247"
      },
      presets: [
        {
          id: "workshop",
          name: "Weathered thatch workshop",
          description: "Weathered thatch workshop proportions",
          parameters: {
            roofCover: "thatch",
            roofThickness: 0.28,
            ridgeSag: 1.1,
            roofCharacter: 0.6,
            beamSection: 1.15,
            weathering: 0.55,
            timberTone: 0.3
          }
        },
        {
          id: "compact",
          name: "Clean shingle cottage",
          description: "Clean shingle cottage proportions",
          parameters: {
            width: 3.6,
            depth: 3.2,
            wallHeight: 2.5,
            roofRise: 1.15,
            roofCover: "shingle",
            roofThickness: 0.16,
            windowLayout: "workshop",
            framingStyle: "upright",
            workBay: "none",
            roofCharacter: 0.1,
            ridgeSag: 0.4,
            beamSection: 0.85,
            weathering: 0.1,
            timberTone: 0.5
          }
        },
        {
          id: "longhouse",
          name: "Deep sheltered longhouse",
          description: "Deep sheltered longhouse proportions",
          parameters: {
            width: 7.2,
            depth: 4.6,
            wallHeight: 2.8,
            roofRise: 1.65,
            roofCover: "thatch",
            roofThickness: 0.34,
            windowLayout: "sparse",
            framingStyle: "diagonal",
            workBay: "none",
            roofCharacter: 0.7,
            ridgeSag: 1.1,
            beamSection: 1.25,
            weathering: 0.7,
            timberTone: 0.25
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#e2d6b8",
            "#b7a16b",
            "#49382c"
          ]
        },
        {
          id: "harbor",
          label: "Harbor",
          colors: [
            "#e4dfcb",
            "#b0a078",
            "#49382c"
          ]
        },
        {
          id: "ember",
          label: "Ember",
          colors: [
            "#dfc69a",
            "#b79558",
            "#49382c"
          ]
        }
      ],
      controls: [
        {
          kind: "range",
          key: "width",
          label: "Footprint width",
          default: 5,
          min: 3.6,
          max: 7.2,
          step: 0.05,
          group: "shape",
          hint: "Roof rise must be at most 0.4 \xD7 footprint width. Widen the footprint or lower roof rise.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "depth",
          label: "Footprint depth",
          default: 4,
          min: 3,
          max: 5.5,
          step: 0.05,
          group: "shape",
          hint: "Roof rise must be at most 0.4 \xD7 footprint width. Widen the footprint or lower roof rise.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "wallHeight",
          label: "Wall height",
          default: 2.8,
          min: 2.5,
          max: 3.4,
          step: 0.05,
          group: "shape",
          hint: "Roof rise must be at most 0.4 \xD7 footprint width. Widen the footprint or lower roof rise.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "roofRise",
          label: "Roof rise",
          default: 1.4,
          min: 1,
          max: 2,
          step: 0.05,
          group: "shape",
          hint: "Roof rise must be at most 0.4 \xD7 footprint width. Widen the footprint or lower roof rise.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "toggle",
          key: "chimney",
          label: "Chimney",
          default: true,
          group: "construction",
          hint: "Include chimney.",
          affects: [
            "topology"
          ],
          targets: [
            "chimney"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "beamWeight",
          label: "Beam section",
          default: "stout",
          options: [
            {
              value: "light",
              label: "Light"
            },
            {
              value: "stout",
              label: "Stout"
            }
          ],
          group: "construction",
          hint: "Select beam section.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "beamWeight"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          key: "eaveOverhang",
          label: "Eave overhang",
          default: 0.4,
          min: 0.25,
          max: 0.55,
          step: 0.01,
          group: "construction",
          hint: "Eave overhang adjusts connected construction.",
          affects: [
            "geometry"
          ],
          targets: [
            "eaveOverhang"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "choice",
          key: "workBay",
          label: "Work bay",
          default: "right",
          options: [
            {
              value: "none",
              label: "None"
            },
            {
              value: "left",
              label: "Left"
            },
            {
              value: "right",
              label: "Right"
            }
          ],
          group: "construction",
          hint: "Select work bay.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "workBay"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "toggle",
          key: "shutters",
          label: "Window shutters",
          default: true,
          group: "construction",
          hint: "Include window shutters.",
          affects: [
            "topology"
          ],
          targets: [
            "shutters"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          key: "roofCharacter",
          label: "Roof profile",
          default: 0.45,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Roof profile adjusts connected construction.",
          affects: [
            "geometry"
          ],
          targets: [
            "roofCharacter"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "detail",
          label: "Detail",
          default: "inspection",
          options: [
            {
              value: "scene",
              label: "Scene"
            },
            {
              value: "inspection",
              label: "Inspection"
            }
          ],
          group: "construction",
          hint: "Select detail.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "detail"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "roofCover",
          label: "Roof covering",
          kind: "choice",
          default: "thatch",
          options: [
            {
              value: "thatch",
              label: "Thatch"
            },
            {
              value: "shingle",
              label: "Shingle"
            }
          ],
          group: "construction",
          hint: "Roof covering reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "cottage"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "roofThickness",
          label: "Roof thickness",
          kind: "range",
          default: 0.24,
          min: 0.14,
          max: 0.38,
          step: 0.01,
          group: "construction",
          hint: "Roof thickness reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "framingStyle",
          label: "Facade framing",
          kind: "choice",
          default: "diagonal",
          options: [
            {
              value: "diagonal",
              label: "Diagonal"
            },
            {
              value: "upright",
              label: "Upright"
            }
          ],
          group: "construction",
          hint: "Facade framing reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "cottage"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "windowLayout",
          label: "Window grouping",
          kind: "choice",
          default: "paired",
          options: [
            {
              value: "paired",
              label: "Paired"
            },
            {
              value: "workshop",
              label: "Workshop"
            },
            {
              value: "sparse",
              label: "Sparse"
            }
          ],
          group: "construction",
          hint: "Window grouping reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "cottage"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "bayDepth",
          label: "Work bay depth",
          kind: "range",
          default: 1.65,
          min: 1.1,
          max: 2.3,
          step: 0.05,
          group: "construction",
          hint: "Work bay depth reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "cottage"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "weathering",
          label: "Timber weathering",
          default: 0.3,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber weathering adjusts connected construction.",
          affects: [
            "geometry",
            "material"
          ],
          targets: [
            "cottage"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "timberTone",
          label: "Timber tone",
          default: 0.35,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber tone adjusts connected construction.",
          affects: [
            "material"
          ],
          targets: [
            "cottage"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "toneVariation",
          label: "Timber tone variation",
          default: 0.06,
          min: 0,
          max: 0.12,
          step: 0.05,
          group: "construction",
          hint: "Timber tone variation adjusts connected construction.",
          affects: [
            "material"
          ],
          targets: [
            "cottage"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "beamSection",
          label: "Beam section multiplier",
          default: 1,
          min: 0.7,
          max: 1.4,
          step: 0.05,
          group: "construction",
          hint: "Beam section multiplier adjusts connected construction.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "ridgeSag",
          label: "Ridge sag multiplier",
          default: 1,
          min: 0.25,
          max: 1.15,
          step: 0.05,
          group: "construction",
          hint: "Ridge sag multiplier adjusts connected construction.",
          affects: [
            "geometry"
          ],
          targets: [
            "cottage"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "Forest"
            },
            {
              value: "harbor",
              label: "Harbor"
            },
            {
              value: "ember",
              label: "Ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.plaster",
          label: "plaster",
          role: "plaster",
          default: "#e2d6b8",
          group: "colors",
          hint: "Changes only plaster color.",
          affects: [
            "material"
          ],
          targets: [
            "plaster"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.roof",
          label: "roof",
          role: "roof",
          default: "#b7a16b",
          group: "colors",
          hint: "Changes only roof color.",
          affects: [
            "material"
          ],
          targets: [
            "roof"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.timber",
          label: "timber",
          role: "timber",
          default: "#49382c",
          group: "colors",
          hint: "Changes only timber color.",
          affects: [
            "material"
          ],
          targets: [
            "timber"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.wood",
          label: "wood",
          role: "wood",
          default: "#966c48",
          group: "colors",
          hint: "Changes only wood color.",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.recess",
          label: "recess",
          role: "recess",
          default: "#34433e",
          group: "colors",
          hint: "Changes only recess color.",
          affects: [
            "material"
          ],
          targets: [
            "recess"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.stone",
          label: "stone",
          role: "stone",
          default: "#7d8279",
          group: "colors",
          hint: "Changes only stone color.",
          affects: [
            "material"
          ],
          targets: [
            "stone"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.hardware",
          label: "hardware",
          role: "hardware",
          default: "#b99247",
          group: "colors",
          hint: "Changes only hardware color.",
          affects: [
            "material"
          ],
          targets: [
            "hardware"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    crate: {
      title: "Supply crate",
      version: "0.6.0",
      description: "Timber storage with open slats or closed sides.",
      defaults: {
        width: 0.9,
        height: 0.7,
        depth: 0.7,
        lid: "open-top",
        brace: "plain",
        detail: "inspection",
        plankCourses: 4,
        slatGap: 0.035,
        frameWeight: "stout",
        toneVariation: 0.06,
        weathering: 0.3,
        timberTone: 0.35,
        colorway: "forest",
        "color.wood": "#bd9458",
        "color.timber": "#a57c48"
      },
      presets: [
        {
          id: "supply",
          name: "Closed shipping chest",
          description: "Closed shipping chest proportions",
          parameters: {
            lid: "closed",
            brace: "diagonal",
            weathering: 0.15,
            timberTone: 0.25,
            slatGap: 0.01
          }
        },
        {
          id: "shallow",
          name: "Golden produce crate",
          description: "Golden produce crate proportions",
          parameters: {
            width: 1.1,
            height: 0.5,
            depth: 0.75,
            lid: "open-top",
            brace: "plain",
            plankCourses: 4,
            slatGap: 0.035,
            frameWeight: "stout",
            weathering: 0.35,
            timberTone: 0.6
          }
        },
        {
          id: "tall",
          name: "Weathered tall storage",
          description: "Weathered tall storage proportions",
          parameters: {
            width: 0.8,
            height: 1.15,
            depth: 0.8,
            plankCourses: 6,
            slatGap: 0.024,
            lid: "open-top",
            brace: "diagonal",
            weathering: 0.8,
            timberTone: 0.35,
            toneVariation: 0.1
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#bd9458",
            "#a57c48"
          ]
        },
        {
          id: "harbor",
          label: "Harbor",
          colors: [
            "#bd9458",
            "#a57c48"
          ]
        },
        {
          id: "ember",
          label: "Ember",
          colors: [
            "#bd9458",
            "#a57c48"
          ]
        }
      ],
      controls: [
        {
          kind: "range",
          key: "width",
          label: "Width",
          default: 0.9,
          min: 0.45,
          max: 1.5,
          step: 0.05,
          group: "shape",
          hint: "Height must be at most 1.6 \xD7 the smaller of width and depth. Lower height or increase the smaller footprint dimension.",
          affects: [
            "geometry"
          ],
          targets: [
            "crate"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "height",
          label: "Height",
          default: 0.7,
          min: 0.35,
          max: 1.2,
          step: 0.05,
          group: "shape",
          hint: "Height must be at most 1.6 \xD7 the smaller of width and depth. Lower height or increase the smaller footprint dimension.",
          affects: [
            "geometry"
          ],
          targets: [
            "crate"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "depth",
          label: "Depth",
          default: 0.7,
          min: 0.4,
          max: 1.2,
          step: 0.05,
          group: "shape",
          hint: "Height must be at most 1.6 \xD7 the smaller of width and depth. Lower height or increase the smaller footprint dimension.",
          affects: [
            "geometry"
          ],
          targets: [
            "crate"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "lid",
          kind: "choice",
          group: "construction",
          label: "Lid",
          default: "open-top",
          options: [
            {
              value: "closed",
              label: "Closed lid"
            },
            {
              value: "open-top",
              label: "Open top"
            }
          ],
          hint: "Removes the lid to expose the real floor and interior.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "lid-*",
            "corner-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "brace",
          kind: "choice",
          group: "construction",
          label: "Side brace",
          default: "plain",
          options: [
            {
              value: "plain",
              label: "Plain"
            },
            {
              value: "diagonal",
              label: "Diagonal brace"
            }
          ],
          hint: "Adds a seated diagonal brace between frame members.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "lid-*",
            "corner-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "detail",
          kind: "choice",
          group: "construction",
          label: "Detail",
          default: "inspection",
          options: [
            {
              value: "scene",
              label: "Scene"
            },
            {
              value: "inspection",
              label: "Inspection"
            }
          ],
          hint: "Inspection adds selected joint hardware; boards and frame stay intact.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "lid-*",
            "corner-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "integer",
          default: 4,
          min: 3,
          max: 6,
          key: "plankCourses",
          label: "Plank courses",
          group: "construction",
          hint: "Fits this many horizontal wall boards between the bottom support and top rim.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "front-plank-*",
            "side-plank-*"
          ],
          step: 1,
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          kind: "range",
          default: 0.035,
          min: 8e-3,
          max: 0.055,
          step: 1e-3,
          key: "slatGap",
          label: "Slat gap",
          group: "construction",
          hint: "Clear vertical gaps between wall boards; floor and lid gaps are capped for support.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "front-plank-*",
            "side-plank-*",
            "floor-board-*",
            "lid-plank-*"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "choice",
          default: "stout",
          options: [
            {
              value: "light",
              label: "Light"
            },
            {
              value: "stout",
              label: "Stout"
            }
          ],
          key: "frameWeight",
          label: "Frame section",
          group: "construction",
          hint: "Changes corner and rim sections and refits the boards to their inner span.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "corner-*",
            "face-rim-*",
            "side-rim-*",
            "front-plank-*",
            "side-plank-*",
            "diagonal-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          ratioBasis: "normalized",
          default: 0.06,
          min: 0,
          max: 0.12,
          step: 0.01,
          key: "toneVariation",
          label: "Board tone variation",
          group: "construction",
          hint: "Adds restrained repeating light and dark board tones derived from the Boards color; shape stays unchanged.",
          affects: [
            "material"
          ],
          targets: [
            "wood-tone-*"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "weathering",
          label: "Timber weathering",
          default: 0.3,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber weathering adjusts connected construction.",
          affects: [
            "geometry",
            "material"
          ],
          targets: [
            "crate"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "timberTone",
          label: "Timber tone",
          default: 0.35,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber tone adjusts connected construction.",
          affects: [
            "material"
          ],
          targets: [
            "crate"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "Forest"
            },
            {
              value: "harbor",
              label: "Harbor"
            },
            {
              value: "ember",
              label: "Ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.wood",
          label: "Boards",
          role: "wood",
          default: "#bd9458",
          group: "colors",
          hint: "Changes only wood color.",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.timber",
          label: "Frame",
          role: "timber",
          default: "#a57c48",
          group: "colors",
          hint: "Changes only timber color.",
          affects: [
            "material"
          ],
          targets: [
            "timber"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    fence: {
      title: "Wooden fence",
      version: "0.6.0",
      description: "An open wooden boundary.",
      defaults: {
        length: 3,
        height: 1.1,
        bays: 2,
        railStyle: "two-rail",
        postHead: "chamfered",
        detail: "inspection",
        railCount: 2,
        memberWeight: "stout",
        infill: "open",
        picketSpacing: 0.16,
        weathering: 0.3,
        timberTone: 0.35,
        toneVariation: 0.06,
        colorway: "forest",
        "color.timber": "#896039",
        "color.wood": "#b68747"
      },
      presets: [
        {
          id: "garden",
          name: "Peaked garden pickets",
          description: "Peaked garden pickets proportions",
          parameters: {
            length: 2.4,
            height: 0.95,
            bays: 2,
            infill: "pickets",
            railCount: 2,
            picketSpacing: 0.13,
            postHead: "peaked",
            weathering: 0.15,
            timberTone: 0.55
          }
        },
        {
          id: "boundary",
          name: "Four-rail boundary",
          description: "Four-rail boundary proportions",
          parameters: {
            length: 4.8,
            height: 1.4,
            bays: 3,
            railStyle: "cross-braced",
            railCount: 4,
            memberWeight: "stout",
            weathering: 0.65,
            timberTone: 0.25,
            toneVariation: 0.09
          }
        },
        {
          id: "low-run",
          name: "Light pasture rails",
          description: "Light pasture rails proportions",
          parameters: {
            length: 5.6,
            height: 0.8,
            bays: 4,
            railCount: 2,
            memberWeight: "light",
            postHead: "flat",
            weathering: 0.4,
            timberTone: 0.65
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#896039",
            "#b68747"
          ]
        },
        {
          id: "harbor",
          label: "Harbor",
          colors: [
            "#896039",
            "#b68747"
          ]
        },
        {
          id: "ember",
          label: "Ember",
          colors: [
            "#896039",
            "#b68747"
          ]
        }
      ],
      controls: [
        {
          kind: "range",
          key: "length",
          label: "Post center length",
          default: 3,
          min: 1.2,
          max: 6,
          step: 0.05,
          group: "shape",
          hint: "Post-center length divided by rail bays must be 0.6\u20132 m. Increase bays or reduce length above 2 m; reduce bays or increase length below 0.6 m.",
          affects: [
            "geometry"
          ],
          targets: [
            "fence"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "height",
          label: "Post height",
          default: 1.1,
          min: 0.7,
          max: 1.5,
          step: 0.05,
          group: "shape",
          hint: "Post-center length divided by rail bays must be 0.6\u20132 m. Increase bays or reduce length above 2 m; reduce bays or increase length below 0.6 m.",
          affects: [
            "geometry"
          ],
          targets: [
            "fence"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "integer",
          key: "bays",
          label: "Rail bays",
          default: 2,
          min: 1,
          max: 4,
          step: 1,
          group: "shape",
          hint: "Post-center length divided by rail bays must be 0.6\u20132 m. Increase bays or reduce length above 2 m; reduce bays or increase length below 0.6 m.",
          affects: [
            "geometry"
          ],
          targets: [
            "fence"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "railStyle",
          kind: "choice",
          group: "construction",
          label: "Rail construction",
          default: "two-rail",
          options: [
            {
              value: "two-rail",
              label: "Two rails"
            },
            {
              value: "cross-braced",
              label: "Cross braced"
            }
          ],
          hint: "Adds a supported diagonal brace inside each rail bay.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "post-*",
            "rail-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "postHead",
          kind: "choice",
          group: "construction",
          label: "Post head",
          default: "chamfered",
          options: [
            {
              value: "flat",
              label: "Flat cut"
            },
            {
              value: "chamfered",
              label: "Chamfered head"
            },
            {
              value: "peaked",
              label: "Peaked"
            }
          ],
          hint: "Changes the top profile while keeping post height and modular endpoints.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "post-*",
            "rail-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "detail",
          kind: "choice",
          group: "construction",
          label: "Detail",
          default: "inspection",
          options: [
            {
              value: "scene",
              label: "Scene"
            },
            {
              value: "inspection",
              label: "Inspection"
            }
          ],
          hint: "Inspection adds joint pegs; structural rails and supports remain in both tiers.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "post-*",
            "rail-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "integer",
          default: 2,
          min: 2,
          max: 4,
          key: "railCount",
          label: "Rail count",
          group: "construction",
          hint: "Places two to four supported horizontal rails in each bay.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "rail-*",
            "joint-peg-*"
          ],
          step: 1,
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          kind: "choice",
          default: "stout",
          options: [
            {
              value: "light",
              label: "Light"
            },
            {
              value: "stout",
              label: "Stout"
            }
          ],
          key: "memberWeight",
          label: "Member section",
          group: "construction",
          hint: "Changes post, rail and picket sections together while preserving the run length.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "post-*",
            "post-cap-*",
            "rail-*",
            "picket-*",
            "brace-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          default: "open",
          options: [
            {
              value: "open",
              label: "Open"
            },
            {
              value: "pickets",
              label: "Pickets"
            }
          ],
          key: "infill",
          label: "Infill",
          group: "construction",
          hint: "Adds pointed timber pickets between the posts.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "picket-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          default: 0.16,
          min: 0.1,
          max: 0.25,
          step: 0.01,
          key: "picketSpacing",
          label: "Picket spacing",
          group: "construction",
          hint: "Target picket center spacing in meters; each bay fits a whole number with at least 20 mm between boards.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "picket-*"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "weathering",
          label: "Timber weathering",
          default: 0.3,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber weathering adjusts connected construction.",
          affects: [
            "geometry",
            "material"
          ],
          targets: [
            "fence"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "timberTone",
          label: "Timber tone",
          default: 0.35,
          min: 0,
          max: 1,
          step: 0.05,
          group: "construction",
          hint: "Timber tone adjusts connected construction.",
          affects: [
            "material"
          ],
          targets: [
            "fence"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "range",
          key: "toneVariation",
          label: "Timber tone variation",
          default: 0.06,
          min: 0,
          max: 0.12,
          step: 0.05,
          group: "construction",
          hint: "Timber tone variation adjusts connected construction.",
          affects: [
            "material"
          ],
          targets: [
            "fence"
          ],
          ratioBasis: "normalized",
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "Forest"
            },
            {
              value: "harbor",
              label: "Harbor"
            },
            {
              value: "ember",
              label: "Ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.timber",
          label: "Posts",
          role: "timber",
          default: "#896039",
          group: "colors",
          hint: "Changes only timber color.",
          affects: [
            "material"
          ],
          targets: [
            "timber"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.wood",
          label: "Rails",
          role: "wood",
          default: "#b68747",
          group: "colors",
          hint: "Changes only wood color.",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    hydrangea: {
      title: "Hydrangea",
      version: "1.0.0",
      description: "Faceted flowering bush with leaf mounds, round flower heads and a soil base.",
      defaults: {
        width: 1.3,
        height: 1.1,
        mounds: 6,
        flowers: 16,
        seed: 21,
        colorway: "blue",
        "color.foliage": "#4f8a4a",
        "color.shade": "#33643a",
        "color.accent": "#7f9be6",
        "color.ground": "#5a4532"
      },
      presets: [
        {
          id: "blue",
          name: "Blue hydrangea",
          description: "Round green bush with blue flower heads.",
          parameters: {}
        },
        {
          id: "pink",
          name: "Pink hydrangea",
          description: "Wide pink bush with many heads.",
          parameters: {
            colorway: "pink",
            width: 1.6,
            height: 1.05,
            mounds: 7,
            flowers: 22,
            seed: 5
          }
        },
        {
          id: "white",
          name: "White hydrangea",
          description: "Tall white bush.",
          parameters: {
            colorway: "white",
            width: 1.25,
            height: 1.2,
            mounds: 6,
            flowers: 14,
            seed: 88
          }
        }
      ],
      palettes: [
        {
          id: "blue",
          label: "Blue",
          colors: [
            "#4f8a4a",
            "#7f9be6"
          ]
        },
        {
          id: "pink",
          label: "Pink",
          colors: [
            "#4f8a4a",
            "#e58fb4"
          ]
        },
        {
          id: "white",
          label: "White",
          colors: [
            "#4a8246",
            "#eeeadb"
          ]
        }
      ],
      controls: [
        {
          key: "width",
          label: "Width",
          kind: "range",
          group: "shape",
          min: 0.6,
          max: 2.4,
          step: 0.05,
          default: 1.3,
          hint: "Spread of the bush.",
          affects: [
            "geometry"
          ],
          targets: [
            "leaves",
            "flowers"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "height",
          label: "Height",
          kind: "range",
          group: "shape",
          min: 0.5,
          max: 2,
          step: 0.05,
          default: 1.1,
          hint: "Height of the bush.",
          affects: [
            "geometry"
          ],
          targets: [
            "leaves",
            "flowers"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "mounds",
          label: "Leaf mounds",
          kind: "integer",
          group: "construction",
          min: 3,
          max: 9,
          step: 1,
          default: 6,
          hint: "Overlapping leaf masses.",
          affects: [
            "topology"
          ],
          targets: [
            "leaves"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "flowers",
          label: "Flower heads",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 30,
          step: 1,
          default: 16,
          hint: "Round flower clusters on the outside.",
          affects: [
            "topology"
          ],
          targets: [
            "flowers"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "seed",
          label: "Variation seed",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 65535,
          step: 1,
          default: 21,
          hint: "Repeatable layout and facets.",
          affects: [
            "geometry"
          ],
          targets: [
            "leaves",
            "flowers"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "blue",
          options: [
            {
              value: "blue",
              label: "Blue"
            },
            {
              value: "pink",
              label: "Pink"
            },
            {
              value: "white",
              label: "White"
            }
          ],
          hint: "Flower and leaf colors.",
          affects: [
            "material"
          ],
          targets: [
            "leaves",
            "flowers"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.foliage",
          label: "Leaves",
          kind: "color",
          group: "colors",
          default: "#4f8a4a",
          role: "leaves",
          hint: "Upper leaf color.",
          affects: [
            "material"
          ],
          targets: [
            "leaves"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.shade",
          label: "Shaded leaves",
          kind: "color",
          group: "colors",
          default: "#33643a",
          role: "shade",
          hint: "Lower leaf color.",
          affects: [
            "material"
          ],
          targets: [
            "shade"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.accent",
          label: "Flowers",
          kind: "color",
          group: "colors",
          default: "#7f9be6",
          role: "flowers",
          hint: "Flower head color.",
          affects: [
            "material"
          ],
          targets: [
            "flowers"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.ground",
          label: "Soil",
          kind: "color",
          group: "colors",
          default: "#5a4532",
          role: "ground",
          hint: "Soil mound color.",
          affects: [
            "material"
          ],
          targets: [
            "ground"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "mushroom-cluster": {
      title: "Mushroom cluster",
      version: "2.0.0",
      description: "A clump of faceted mushrooms on a moss mound, with dome, bun or cone caps.",
      defaults: {
        count: 5,
        height: 0.35,
        capStyle: "dome",
        capWidth: 0.75,
        spots: true,
        lean: 0.15,
        seed: 7,
        colorway: "toadstool",
        "color.cap": "#c8352b",
        "color.spots": "#f4efe2",
        "color.stem": "#ece4d0",
        "color.ground": "#4d6b3a"
      },
      presets: [
        {
          id: "toadstool",
          name: "Toadstools",
          description: "Red spotted toadstools on a moss mound.",
          parameters: {}
        },
        {
          id: "porcini",
          name: "Porcini",
          description: "Fat-stemmed porcini with brown bun caps.",
          parameters: {
            colorway: "porcini",
            capStyle: "flat",
            spots: false,
            count: 4,
            capWidth: 0.95,
            lean: 0.08,
            seed: 12
          }
        },
        {
          id: "glow",
          name: "Giant glowcap",
          description: "Tall blue glowcaps with glowing spots.",
          parameters: {
            colorway: "glow",
            capStyle: "cone",
            height: 1.9,
            count: 5,
            capWidth: 0.6,
            lean: 0.22,
            seed: 31
          }
        }
      ],
      palettes: [
        {
          id: "toadstool",
          label: "Toadstool",
          colors: [
            "#c8352b",
            "#ece4d0"
          ]
        },
        {
          id: "porcini",
          label: "Porcini",
          colors: [
            "#7a4a2a",
            "#e2d3b0"
          ]
        },
        {
          id: "glow",
          label: "Glow",
          colors: [
            "#2f6fb3",
            "#cfe3ea"
          ]
        }
      ],
      controls: [
        {
          key: "count",
          label: "Mushrooms",
          kind: "integer",
          group: "construction",
          min: 1,
          max: 9,
          step: 1,
          default: 5,
          hint: "Mushrooms in the clump.",
          affects: [
            "topology"
          ],
          targets: [
            "cap",
            "stem"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "height",
          label: "Tallest",
          kind: "range",
          group: "shape",
          min: 0.1,
          max: 2.5,
          step: 0.05,
          default: 0.35,
          hint: "Height of the tallest mushroom.",
          affects: [
            "geometry"
          ],
          targets: [
            "cap",
            "stem"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "capStyle",
          label: "Caps",
          kind: "choice",
          group: "construction",
          default: "dome",
          options: [
            {
              value: "dome",
              label: "Dome"
            },
            {
              value: "flat",
              label: "Bun"
            },
            {
              value: "cone",
              label: "Cone"
            }
          ],
          hint: "Cap shape.",
          affects: [
            "geometry"
          ],
          targets: [
            "cap"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "capWidth",
          label: "Cap width",
          kind: "range",
          group: "shape",
          min: 0.4,
          max: 1.2,
          step: 0.05,
          default: 0.75,
          hint: "Cap width relative to height.",
          affects: [
            "geometry"
          ],
          targets: [
            "cap"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "spots",
          label: "Spots",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Raised spots on the caps.",
          affects: [
            "geometry"
          ],
          targets: [
            "spots"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "lean",
          label: "Lean",
          kind: "range",
          group: "shape",
          min: 0,
          max: 0.4,
          step: 0.01,
          default: 0.15,
          hint: "How far the outer mushrooms lean out.",
          affects: [
            "geometry"
          ],
          targets: [
            "stem"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "seed",
          label: "Variation seed",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 65535,
          step: 1,
          default: 7,
          hint: "Repeatable layout.",
          affects: [
            "geometry"
          ],
          targets: [
            "cap",
            "stem"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "toadstool",
          options: [
            {
              value: "toadstool",
              label: "Toadstool"
            },
            {
              value: "porcini",
              label: "Porcini"
            },
            {
              value: "glow",
              label: "Glow"
            }
          ],
          hint: "Mushroom colors.",
          affects: [
            "material"
          ],
          targets: [
            "cap",
            "spots",
            "stem",
            "ground"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.cap",
          label: "Cap",
          kind: "color",
          group: "colors",
          default: "#c8352b",
          role: "cap",
          hint: "Cap color.",
          affects: [
            "material"
          ],
          targets: [
            "cap"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.spots",
          label: "Spots",
          kind: "color",
          group: "colors",
          default: "#f4efe2",
          role: "spots",
          hint: "Spot color.",
          affects: [
            "material"
          ],
          targets: [
            "spots"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.stem",
          label: "Stem",
          kind: "color",
          group: "colors",
          default: "#ece4d0",
          role: "stem",
          hint: "Stem and gill color.",
          affects: [
            "material"
          ],
          targets: [
            "stem"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.ground",
          label: "Moss",
          kind: "color",
          group: "colors",
          default: "#4d6b3a",
          role: "ground",
          hint: "Moss mound color.",
          affects: [
            "material"
          ],
          targets: [
            "ground"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    planter: {
      title: "Slatted planter box",
      version: "1.1.0",
      description: "An open planter with stacked wall boards, corner posts, a floor and optional feet.",
      defaults: {
        width: 1.1,
        depth: 0.5,
        height: 0.5,
        boardCount: 3,
        feet: true,
        colorway: "oak",
        "color.wood": "#b88654",
        "color.frame": "#604532"
      },
      presets: [
        {
          id: "raised-box",
          name: "Raised box",
          description: "Three oak board courses with four raised feet.",
          parameters: {}
        },
        {
          id: "herb-trough",
          name: "Herb trough",
          description: "A low long oak box resting on the ground.",
          parameters: {
            width: 1.5,
            depth: 0.4,
            height: 0.3,
            boardCount: 2,
            feet: false
          }
        },
        {
          id: "patio-box",
          name: "Patio box",
          description: "A tall square painted planter on feet.",
          parameters: {
            width: 0.7,
            depth: 0.7,
            height: 0.8,
            boardCount: 5,
            feet: true,
            colorway: "painted"
          }
        }
      ],
      palettes: [
        {
          id: "oak",
          label: "Oak",
          colors: [
            "#b88654",
            "#604532"
          ]
        },
        {
          id: "painted",
          label: "Painted",
          colors: [
            "#8ca58b",
            "#384a42"
          ]
        }
      ],
      controls: [
        {
          key: "width",
          label: "width",
          kind: "range",
          group: "shape",
          min: 0.6,
          max: 1.8,
          step: 0.05,
          default: 1.1,
          hint: "Outside width in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "wall",
            "post",
            "floor",
            "foot",
            "rim"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "depth",
          label: "depth",
          kind: "range",
          group: "shape",
          min: 0.3,
          max: 0.8,
          step: 0.05,
          default: 0.5,
          hint: "Outside depth in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "wall",
            "post",
            "floor",
            "foot",
            "rim"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "height",
          label: "height",
          kind: "range",
          group: "shape",
          min: 0.25,
          max: 0.85,
          step: 0.05,
          default: 0.5,
          hint: "Outside height in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "wall",
            "post",
            "floor",
            "foot",
            "rim"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "boardCount",
          label: "Wall boards",
          kind: "integer",
          group: "construction",
          min: 2,
          max: 5,
          step: 1,
          default: 3,
          hint: "Horizontal board courses with small gaps.",
          affects: [
            "topology"
          ],
          targets: [
            "wall",
            "post",
            "floor",
            "foot",
            "rim"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "feet",
          label: "Raised feet",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Adds four ground-supported feet below the floor.",
          affects: [
            "topology"
          ],
          targets: [
            "wall",
            "post",
            "floor",
            "foot",
            "rim"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "oak",
          options: [
            {
              value: "oak",
              label: "Oak"
            },
            {
              value: "painted",
              label: "Painted"
            }
          ],
          hint: "Board and post colors.",
          affects: [
            "material"
          ],
          targets: [
            "wood",
            "frame",
            "rim"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.wood",
          label: "Boards",
          kind: "color",
          group: "colors",
          default: "#b88654",
          role: "wood",
          hint: "Walls and floor.",
          affects: [
            "material"
          ],
          targets: [
            "wall",
            "floor",
            "rim"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.frame",
          label: "Posts",
          kind: "color",
          group: "colors",
          default: "#604532",
          role: "frame",
          hint: "Posts and feet.",
          affects: [
            "material"
          ],
          targets: [
            "post",
            "foot"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "rigged-rabbit": {
      title: "Stylized rabbit",
      version: "1.0.0",
      description: "Faceted wild rabbit with a short muzzle, cream belly, cotton tail and long ears.",
      defaults: {
        bodyLength: 0.4,
        earRatio: 0.62,
        haunch: 1,
        legRatio: 1,
        headRatio: 1,
        earStyle: "upright",
        build: "standard",
        earTips: false,
        "color.fur": "#998d7d",
        "color.cream": "#e6e2da",
        "color.dark": "#1d1714"
      },
      presets: [
        {
          id: "cottontail",
          name: "Cottontail",
          description: "Brown wild rabbit with upright ears and a white cotton tail.",
          parameters: {}
        },
        {
          id: "lop",
          name: "Lop rabbit",
          description: "Stocky grey-and-white pet rabbit with lop ears hanging beside a big head.",
          parameters: {
            earStyle: "lop",
            build: "stocky",
            earRatio: 0.7,
            headRatio: 1.15,
            haunch: 1.15,
            legRatio: 0.85,
            bodyLength: 0.32,
            "color.fur": "#8f8f93",
            "color.cream": "#f4f2ee",
            "color.dark": "#262426"
          }
        },
        {
          id: "hare",
          name: "Hare",
          description: "Lean long-legged tawny hare with long swept ears and black tips.",
          parameters: {
            earStyle: "swept",
            build: "lean",
            earRatio: 1,
            legRatio: 1.28,
            haunch: 0.95,
            headRatio: 0.92,
            bodyLength: 0.46,
            earTips: true,
            "color.fur": "#b98a52",
            "color.cream": "#efe3cb",
            "color.dark": "#221d1a"
          }
        }
      ],
      palettes: [],
      controls: [
        {
          key: "bodyLength",
          label: "Body length",
          kind: "range",
          group: "shape",
          min: 0.26,
          max: 0.5,
          step: 5e-3,
          default: 0.4,
          hint: "Body length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "earRatio",
          label: "Ear length",
          kind: "range",
          group: "shape",
          min: 0.45,
          max: 1.05,
          step: 5e-3,
          default: 0.62,
          hint: "Ear length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "haunch",
          label: "Haunch size",
          kind: "range",
          group: "shape",
          min: 0.85,
          max: 1.25,
          step: 5e-3,
          default: 1,
          hint: "Haunch size",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "legRatio",
          label: "Leg length",
          kind: "range",
          group: "shape",
          min: 0.8,
          max: 1.3,
          step: 5e-3,
          default: 1,
          hint: "Leg length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "headRatio",
          label: "Head size",
          kind: "range",
          group: "shape",
          min: 0.85,
          max: 1.2,
          step: 5e-3,
          default: 1,
          hint: "Head size",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "earStyle",
          label: "Ears",
          kind: "choice",
          group: "construction",
          default: "upright",
          options: [
            {
              value: "upright",
              label: "Upright"
            },
            {
              value: "lop",
              label: "Lop"
            },
            {
              value: "swept",
              label: "Swept"
            }
          ],
          hint: "Upright rabbit ears, lop ears hanging beside the head, or long hare ears swept back.",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "build",
          label: "Build",
          kind: "choice",
          group: "construction",
          default: "standard",
          options: [
            {
              value: "standard",
              label: "Standard"
            },
            {
              value: "stocky",
              label: "Stocky"
            },
            {
              value: "lean",
              label: "Lean"
            }
          ],
          hint: "Body girth.",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "earTips",
          label: "Dark ear tips",
          kind: "toggle",
          group: "construction",
          default: false,
          hint: "Hare-style black ear tips.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.fur",
          label: "fur",
          kind: "color",
          group: "colors",
          default: "#998d7d",
          role: "fur",
          hint: "fur material",
          affects: [
            "material"
          ],
          targets: [
            "fur"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.cream",
          label: "cream",
          kind: "color",
          group: "colors",
          default: "#e6e2da",
          role: "cream",
          hint: "cream material",
          affects: [
            "material"
          ],
          targets: [
            "cream"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.dark",
          label: "dark",
          kind: "color",
          group: "colors",
          default: "#1d1714",
          role: "dark",
          hint: "dark material",
          affects: [
            "material"
          ],
          targets: [
            "dark"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "rock-cluster": {
      title: "Rock cluster",
      version: "1.2.0",
      description: "Faceted stones and pebbles with moss on the surface.",
      defaults: {
        count: 5,
        size: 1.2,
        spread: 1.1,
        flatness: 0.7,
        pebbles: 6,
        seed: 101,
        colorway: "granite",
        "color.stone": "#8d8a85",
        "color.accent": "#6f6b66"
      },
      presets: [
        {
          id: "outcrop",
          name: "Outcrop",
          description: "Five granite stones with grounded pebbles.",
          parameters: {}
        },
        {
          id: "slabs",
          name: "Slab field",
          description: "Low sandstone slabs.",
          parameters: {
            count: 7,
            size: 0.6,
            flatness: 0.35,
            spread: 1.6,
            colorway: "sandstone",
            seed: 77
          }
        },
        {
          id: "monolith",
          name: "Monolith",
          description: "One tall mossy stone with rubble at the base.",
          parameters: {
            count: 1,
            size: 2.8,
            flatness: 1.2,
            pebbles: 8,
            colorway: "mossy",
            seed: 9
          }
        }
      ],
      palettes: [
        {
          id: "granite",
          label: "Granite",
          colors: [
            "#8d8a85",
            "#6f6b66"
          ]
        },
        {
          id: "sandstone",
          label: "Sandstone",
          colors: [
            "#c2a077",
            "#a07f58"
          ]
        },
        {
          id: "basalt",
          label: "Basalt",
          colors: [
            "#45474b",
            "#5c5e62"
          ]
        },
        {
          id: "mossy",
          label: "Mossy",
          colors: [
            "#7f8478",
            "#5d7343"
          ]
        }
      ],
      controls: [
        {
          key: "count",
          label: "Rocks",
          kind: "integer",
          group: "construction",
          min: 1,
          max: 9,
          step: 1,
          default: 5,
          hint: "Main stones in the cluster.",
          affects: [
            "topology"
          ],
          targets: [
            "rock",
            "pebble"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "size",
          label: "Largest rock",
          kind: "range",
          group: "shape",
          min: 0.3,
          max: 3,
          step: 0.05,
          default: 1.2,
          hint: "Height of the largest stone.",
          affects: [
            "geometry"
          ],
          targets: [
            "rock",
            "pebble"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "spread",
          label: "Spread",
          kind: "range",
          group: "shape",
          min: 0.6,
          max: 2,
          step: 0.05,
          default: 1.1,
          hint: "How far stones spread from the center, relative to size.",
          affects: [
            "geometry"
          ],
          targets: [
            "rock",
            "pebble"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "flatness",
          label: "Flatness",
          kind: "range",
          group: "shape",
          min: 0.3,
          max: 1.2,
          step: 0.05,
          default: 0.7,
          hint: "Height to width of each stone. Low values make slabs.",
          affects: [
            "geometry"
          ],
          targets: [
            "rock",
            "pebble"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "pebbles",
          label: "Pebbles",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 12,
          step: 1,
          default: 6,
          hint: "Small grounded stones around the cluster.",
          affects: [
            "topology"
          ],
          targets: [
            "pebble"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "seed",
          label: "Variation seed",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 65535,
          step: 1,
          default: 101,
          hint: "Repeatable facets and layout.",
          affects: [
            "geometry"
          ],
          targets: [
            "rock",
            "pebble"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "granite",
          options: [
            {
              value: "granite",
              label: "Granite"
            },
            {
              value: "sandstone",
              label: "Sandstone"
            },
            {
              value: "basalt",
              label: "Basalt"
            },
            {
              value: "mossy",
              label: "Mossy"
            }
          ],
          hint: "Stone and moss colors.",
          affects: [
            "material"
          ],
          targets: [
            "stone",
            "moss"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.stone",
          label: "Stone",
          kind: "color",
          group: "colors",
          default: "#8d8a85",
          role: "stone",
          hint: "Main stone color.",
          affects: [
            "material"
          ],
          targets: [
            "stone"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.accent",
          label: "Moss",
          kind: "color",
          group: "colors",
          default: "#6f6b66",
          role: "moss",
          hint: "Moss and weathered caps.",
          affects: [
            "material"
          ],
          targets: [
            "moss"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    slime: {
      title: "Slime creature",
      version: "2.0.0",
      description: "A jelly slime sculpted as one closed body, with a puddled base, drips, expressive eyes and mouth, and an optional crown or rock crust.",
      defaults: {
        height: 0.7,
        width: 0.9,
        form: "drop",
        mood: "happy",
        eyeSize: 0.13,
        crown: false,
        crust: false,
        seed: 7,
        colorway: "lime",
        "color.body": "#6fcf4f",
        "color.shine": "#c9f5a8",
        "color.eye": "#fbfbf6",
        "color.pupil": "#1f2a24",
        "color.accent": "#3d8a3a",
        "color.glow": "#ff8fa3"
      },
      presets: [
        {
          id: "dew",
          name: "Dew slime",
          description: "Green happy dew drop with a curled tip and a leaf sprout.",
          parameters: {}
        },
        {
          id: "king",
          name: "King slime",
          description: "Wide sleepy blue dome wearing a gold crown.",
          parameters: {
            height: 0.95,
            width: 1.45,
            form: "dome",
            mood: "sleepy",
            eyeSize: 0.14,
            crown: true,
            colorway: "azure",
            seed: 11
          }
        },
        {
          id: "magma",
          name: "Magma blob",
          description: "Lumpy angry lava blob under cooled rock plates with glowing cracks.",
          parameters: {
            height: 0.8,
            width: 1.05,
            form: "lumpy",
            mood: "angry",
            eyeSize: 0.11,
            crust: true,
            colorway: "magma",
            seed: 29
          }
        }
      ],
      palettes: [
        {
          id: "lime",
          label: "Lime",
          colors: [
            "#6fcf4f",
            "#c9f5a8"
          ]
        },
        {
          id: "azure",
          label: "Azure",
          colors: [
            "#3f8ee0",
            "#bfe0ff"
          ]
        },
        {
          id: "magma",
          label: "Magma",
          colors: [
            "#ff6a1a",
            "#ffd06a"
          ]
        }
      ],
      controls: [
        {
          key: "height",
          label: "Height",
          kind: "range",
          group: "shape",
          min: 0.3,
          max: 1.4,
          step: 0.01,
          default: 0.7,
          hint: "Ground to tip.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "width",
          label: "Width",
          kind: "range",
          group: "shape",
          min: 0.6,
          max: 1.6,
          step: 0.01,
          default: 0.9,
          hint: "Body diameter as a multiple of height.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "form",
          label: "Form",
          kind: "choice",
          group: "construction",
          default: "drop",
          options: [
            {
              value: "drop",
              label: "Dew drop"
            },
            {
              value: "dome",
              label: "Dome"
            },
            {
              value: "lumpy",
              label: "Lumpy"
            }
          ],
          hint: "Pointed drop with a curled tip, a wide jelly dome, or a lumpy multi-lobed blob.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "mood",
          label: "Mood",
          kind: "choice",
          group: "construction",
          default: "happy",
          options: [
            {
              value: "happy",
              label: "Happy"
            },
            {
              value: "sleepy",
              label: "Sleepy"
            },
            {
              value: "angry",
              label: "Angry"
            }
          ],
          hint: "Eyes and mouth.",
          affects: [
            "geometry"
          ],
          targets: [
            "eye",
            "pupil"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "eyeSize",
          label: "Eye size",
          kind: "range",
          group: "shape",
          min: 0.08,
          max: 0.2,
          step: 5e-3,
          default: 0.13,
          hint: "Eye radius as a fraction of height.",
          affects: [
            "geometry"
          ],
          targets: [
            "eye",
            "pupil"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "crown",
          label: "Crown",
          kind: "toggle",
          group: "construction",
          default: false,
          hint: "A little gold crown on top.",
          affects: [
            "topology"
          ],
          targets: [
            "accent",
            "glow"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "crust",
          label: "Rock crust",
          kind: "toggle",
          group: "construction",
          default: false,
          hint: "Cooled rock plates with glowing cracks.",
          affects: [
            "geometry"
          ],
          targets: [
            "accent",
            "glow"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "seed",
          label: "Variation seed",
          kind: "integer",
          group: "construction",
          min: 0,
          max: 65535,
          step: 1,
          default: 7,
          hint: "Repeatable lobes, drips and plates.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "lime",
          options: [
            {
              value: "lime",
              label: "Lime"
            },
            {
              value: "azure",
              label: "Azure"
            },
            {
              value: "magma",
              label: "Magma"
            }
          ],
          hint: "Slime colors.",
          affects: [
            "material"
          ],
          targets: [
            "body",
            "shine",
            "eye",
            "pupil",
            "accent",
            "glow"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.body",
          label: "Body",
          kind: "color",
          group: "colors",
          default: "#6fcf4f",
          role: "body",
          hint: "Jelly body and drips.",
          affects: [
            "material"
          ],
          targets: [
            "body"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.shine",
          label: "Shine",
          kind: "color",
          group: "colors",
          default: "#c9f5a8",
          role: "shine",
          hint: "Highlights and bubbles.",
          affects: [
            "material"
          ],
          targets: [
            "shine"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.eye",
          label: "Eye",
          kind: "color",
          group: "colors",
          default: "#fbfbf6",
          role: "eye",
          hint: "Eye whites.",
          affects: [
            "material"
          ],
          targets: [
            "eye"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.pupil",
          label: "Pupil",
          kind: "color",
          group: "colors",
          default: "#1f2a24",
          role: "pupil",
          hint: "Pupils, brows and mouth.",
          affects: [
            "material"
          ],
          targets: [
            "pupil"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.accent",
          label: "Accent",
          kind: "color",
          group: "colors",
          default: "#3d8a3a",
          role: "accent",
          hint: "Leaf sprout, crown or rock crust.",
          affects: [
            "material"
          ],
          targets: [
            "accent"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.glow",
          label: "Glow",
          kind: "color",
          group: "colors",
          default: "#ff8fa3",
          role: "glow",
          hint: "Gems, cheeks and lava cracks.",
          affects: [
            "material"
          ],
          targets: [
            "glow"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "stone-well": {
      title: "Stone well",
      version: "1.1.0",
      description: "Open masonry shaft, timber shelter, windlass and suspended bucket.",
      defaults: {
        diameter: 2.2,
        wallHeight: 0.95,
        roofSize: 1.35,
        roof: true,
        bucket: true,
        windlass: true,
        bucketDrop: 0,
        "color.stone": "#898880",
        "color.coping": "#b2ac96",
        "color.timber": "#62432e",
        "color.roof": "#a77342",
        "color.iron": "#343b3b",
        "color.rope": "#bca879"
      },
      presets: [
        {
          id: "village",
          name: "Village well",
          description: "Warm timber above a modest stone shaft.",
          parameters: {}
        },
        {
          id: "courtyard",
          name: "Courtyard well",
          description: "Compact open-top well with a lowered suspended bucket.",
          parameters: {
            diameter: 1.8,
            wallHeight: 0.7,
            roofSize: 1.2,
            roof: false,
            bucketDrop: 0.35
          }
        },
        {
          id: "market",
          name: "Market well",
          description: "Broad sheltered shaft with its bucket removed.",
          parameters: {
            diameter: 3,
            wallHeight: 1.25,
            roofSize: 1.5,
            bucket: false
          }
        }
      ],
      palettes: [
        {
          id: "warm",
          label: "Weathered stone and oak",
          colors: [
            "#898880",
            "#b2ac96",
            "#62432e",
            "#a77342",
            "#343b3b",
            "#bca879"
          ]
        }
      ],
      controls: [
        {
          key: "diameter",
          label: "Outside diameter",
          kind: "range",
          group: "shape",
          min: 1.8,
          max: 3.2,
          step: 0.05,
          default: 2.2,
          hint: "Outside masonry diameter. Shaft stays open with 25 cm walls.",
          affects: [
            "geometry"
          ],
          targets: [
            "stone",
            "coping",
            "post",
            "windlass",
            "roof-board"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "wallHeight",
          label: "Wall height",
          kind: "range",
          group: "shape",
          min: 0.65,
          max: 1.4,
          step: 0.05,
          default: 0.95,
          hint: "Ground to coping top. Timber and mechanism follow the wall.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "stone",
            "coping",
            "post",
            "windlass",
            "bucket-shell"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "roofSize",
          label: "Roof size",
          kind: "range",
          group: "shape",
          ratioBasis: "width",
          min: 1.15,
          max: 1.6,
          step: 0.05,
          default: 1.35,
          hint: "Roof width as a multiple of well diameter. Depth is 85 percent of width.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "roof-board",
            "rafter",
            "ridge"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "roof",
          label: "Timber roof",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Roof boards, rafters and braces; posts remain with an open top.",
          affects: [
            "topology"
          ],
          targets: [
            "roof-board",
            "rafter",
            "ridge",
            "fascia",
            "tie",
            "brace",
            "post"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "bucket",
          label: "Suspended bucket",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Bucket, handle and hanging rope. Requires the windlass.",
          affects: [
            "topology"
          ],
          targets: [
            "bucket",
            "hanging-rope"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "windlass",
          label: "Windlass mechanism",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Axle, bearings, crank and rope spool. Remove the bucket before disabling.",
          affects: [
            "topology"
          ],
          targets: [
            "windlass",
            "axle-bearing",
            "spool-flange",
            "crank",
            "rope-coil"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "bucketDrop",
          label: "Bucket drop",
          kind: "range",
          group: "construction",
          min: 0,
          max: 0.6,
          step: 0.05,
          default: 0,
          hint: "Lowers the bucket from its default height and lengthens the hanging rope.",
          affects: [
            "geometry"
          ],
          targets: [
            "bucket",
            "hanging-rope"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "color.stone",
          label: "stone",
          kind: "color",
          group: "colors",
          default: "#898880",
          role: "stone",
          hint: "Color of stone parts.",
          affects: [
            "material"
          ],
          targets: [
            "stone"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.coping",
          label: "coping",
          kind: "color",
          group: "colors",
          default: "#b2ac96",
          role: "coping",
          hint: "Color of coping parts.",
          affects: [
            "material"
          ],
          targets: [
            "coping"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.timber",
          label: "timber",
          kind: "color",
          group: "colors",
          default: "#62432e",
          role: "timber",
          hint: "Color of timber parts.",
          affects: [
            "material"
          ],
          targets: [
            "timber"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.roof",
          label: "roof",
          kind: "color",
          group: "colors",
          default: "#a77342",
          role: "roof",
          hint: "Color of roof parts.",
          affects: [
            "material"
          ],
          targets: [
            "roof"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.iron",
          label: "iron",
          kind: "color",
          group: "colors",
          default: "#343b3b",
          role: "iron",
          hint: "Color of iron parts.",
          affects: [
            "material"
          ],
          targets: [
            "iron"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.rope",
          label: "rope",
          kind: "color",
          group: "colors",
          default: "#bca879",
          role: "rope",
          hint: "Color of rope parts.",
          affects: [
            "material"
          ],
          targets: [
            "rope"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "stylized-fox": {
      title: "Stylized fox",
      version: "1.1.0",
      description: "Original quadruped with tapered muzzle, upright ears and a weighted bushy tail.",
      defaults: {
        bodyLength: 0.44,
        heightRatio: 0.8,
        chestRatio: 0.34,
        headRatio: 0.36,
        earRatio: 0.48,
        muzzleRatio: 0.45,
        tailRatio: 1.05,
        tailFullness: 0.16,
        "color.fur": "#b95b32",
        "color.cream": "#eadbc4",
        "color.dark": "#332c2a"
      },
      presets: [
        {
          id: "default",
          name: "Russet fox",
          description: "Russet coat with cream underside, dark socks and ear tips.",
          parameters: {}
        },
        {
          id: "silver",
          name: "Silver fox",
          description: "Charcoal-grey coat with a white tail tip.",
          parameters: {
            "color.fur": "#5d5a5c",
            "color.cream": "#e9e7e3",
            "color.dark": "#1f1d1e"
          }
        },
        {
          id: "arctic",
          name: "Arctic fox",
          description: "White winter coat with small ears and a full tail.",
          parameters: {
            "color.fur": "#ecebe6",
            "color.cream": "#ffffff",
            "color.dark": "#a49d96",
            earRatio: 0.38,
            muzzleRatio: 0.38,
            tailFullness: 0.18
          }
        }
      ],
      palettes: [],
      controls: [
        {
          key: "bodyLength",
          label: "Body length",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.75,
          step: 5e-3,
          default: 0.44,
          hint: "Body length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "heightRatio",
          label: "Shoulder height",
          kind: "range",
          group: "shape",
          min: 0.6,
          max: 0.8,
          step: 5e-3,
          default: 0.8,
          hint: "Shoulder height",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "chestRatio",
          label: "Chest width",
          kind: "range",
          group: "shape",
          min: 0.25,
          max: 0.38,
          step: 5e-3,
          default: 0.34,
          hint: "Chest width",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "headRatio",
          label: "Head length",
          kind: "range",
          group: "shape",
          min: 0.26,
          max: 0.38,
          step: 5e-3,
          default: 0.36,
          hint: "Head length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "earRatio",
          label: "Ear height",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.6,
          step: 5e-3,
          default: 0.48,
          hint: "Ear height",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "muzzleRatio",
          label: "Muzzle length",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.55,
          step: 5e-3,
          default: 0.45,
          hint: "Muzzle length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "tailRatio",
          label: "Tail length",
          kind: "range",
          group: "shape",
          min: 0.8,
          max: 1.2,
          step: 5e-3,
          default: 1.05,
          hint: "Tail length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "tailFullness",
          label: "Tail fullness",
          kind: "range",
          group: "shape",
          min: 0.1,
          max: 0.18,
          step: 5e-3,
          default: 0.16,
          hint: "Tail fullness",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "color.fur",
          label: "fur",
          kind: "color",
          group: "colors",
          default: "#b95b32",
          role: "fur",
          hint: "fur material",
          affects: [
            "material"
          ],
          targets: [
            "fur"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.cream",
          label: "cream",
          kind: "color",
          group: "colors",
          default: "#eadbc4",
          role: "cream",
          hint: "cream material",
          affects: [
            "material"
          ],
          targets: [
            "cream"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.dark",
          label: "dark",
          kind: "color",
          group: "colors",
          default: "#332c2a",
          role: "dark",
          hint: "dark material",
          affects: [
            "material"
          ],
          targets: [
            "dark"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "stylized-humanoid": {
      title: "Stylized adventurer",
      version: "1.0.0",
      description: "Low-poly clothed humanoid built from faceted rings, with clothing edges on ring lines and weighted joints.",
      defaults: {
        height: 1.7,
        headRatio: 0.21,
        shoulderRatio: 0.27,
        hipRatio: 0.21,
        legRatio: 0.43,
        armRatio: 0.34,
        limbRatio: 0.046,
        build: "standard",
        sleeves: "long",
        hairStyle: "short",
        beard: false,
        "color.skin": "#c99a78",
        "color.tunic": "#5f7d5a",
        "color.trousers": "#6b5642",
        "color.boots": "#3f332c",
        "color.belt": "#4a3626",
        "color.hair": "#4a3427"
      },
      presets: [
        {
          id: "default",
          name: "Adventurer",
          description: "Green tunic, brown trousers and boots, short hair.",
          parameters: {}
        },
        {
          id: "brawler",
          name: "Brawler",
          description: "Broad, sleeveless fighter with a beard.",
          parameters: {
            build: "broad",
            sleeves: "none",
            beard: true,
            shoulderRatio: 0.31,
            height: 1.82,
            "color.tunic": "#8a3e2e",
            "color.trousers": "#3d3a36",
            "color.skin": "#b5835f",
            "color.hair": "#2a211c"
          }
        },
        {
          id: "monk",
          name: "Monk",
          description: "Slim monk in a saffron robe with a shaved head.",
          parameters: {
            build: "slim",
            hairStyle: "bald",
            sleeves: "short",
            "color.tunic": "#d08a2e",
            "color.trousers": "#7a4a2a",
            "color.belt": "#6b2f1c",
            "color.boots": "#5a4430",
            "color.skin": "#d0a07c"
          }
        }
      ],
      palettes: [],
      controls: [
        {
          key: "height",
          label: "Height",
          kind: "range",
          group: "shape",
          min: 1.2,
          max: 2.2,
          step: 5e-3,
          default: 1.7,
          hint: "Height",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "headRatio",
          label: "Head proportion",
          kind: "range",
          group: "shape",
          min: 0.14,
          max: 0.26,
          step: 5e-3,
          default: 0.21,
          hint: "Head proportion",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "shoulderRatio",
          label: "Shoulder width",
          kind: "range",
          group: "shape",
          min: 0.22,
          max: 0.34,
          step: 5e-3,
          default: 0.27,
          hint: "Shoulder width",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "hipRatio",
          label: "Hip width",
          kind: "range",
          group: "shape",
          min: 0.16,
          max: 0.26,
          step: 5e-3,
          default: 0.21,
          hint: "Hip width",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "legRatio",
          label: "Leg length",
          kind: "range",
          group: "shape",
          min: 0.38,
          max: 0.53,
          step: 5e-3,
          default: 0.43,
          hint: "Leg length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "armRatio",
          label: "Arm length",
          kind: "range",
          group: "shape",
          min: 0.3,
          max: 0.4,
          step: 5e-3,
          default: 0.34,
          hint: "Arm length",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "limbRatio",
          label: "Limb radius",
          kind: "range",
          group: "shape",
          min: 0.035,
          max: 0.065,
          step: 5e-3,
          default: 0.046,
          hint: "Limb radius",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "skeleton"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "build",
          label: "Build",
          kind: "choice",
          group: "construction",
          default: "standard",
          options: [
            {
              value: "standard",
              label: "Standard"
            },
            {
              value: "broad",
              label: "Broad"
            },
            {
              value: "slim",
              label: "Slim"
            }
          ],
          hint: "Torso and limb girth.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "sleeves",
          label: "Sleeves",
          kind: "choice",
          group: "construction",
          default: "long",
          options: [
            {
              value: "long",
              label: "Long"
            },
            {
              value: "short",
              label: "Short"
            },
            {
              value: "none",
              label: "None"
            }
          ],
          hint: "How far the shirt covers the arms.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "hairStyle",
          label: "Hair",
          kind: "choice",
          group: "construction",
          default: "short",
          options: [
            {
              value: "short",
              label: "Short"
            },
            {
              value: "bald",
              label: "Bald"
            },
            {
              value: "topknot",
              label: "Top knot"
            }
          ],
          hint: "Hair on the head.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "beard",
          label: "Beard",
          kind: "toggle",
          group: "construction",
          default: false,
          hint: "Beard over the jaw.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.skin",
          label: "skin",
          kind: "color",
          group: "colors",
          default: "#c99a78",
          role: "skin",
          hint: "skin color",
          affects: [
            "material"
          ],
          targets: [
            "skin"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.tunic",
          label: "tunic",
          kind: "color",
          group: "colors",
          default: "#5f7d5a",
          role: "tunic",
          hint: "tunic color",
          affects: [
            "material"
          ],
          targets: [
            "tunic"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.trousers",
          label: "trousers",
          kind: "color",
          group: "colors",
          default: "#6b5642",
          role: "trousers",
          hint: "trousers color",
          affects: [
            "material"
          ],
          targets: [
            "trousers"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.boots",
          label: "boots",
          kind: "color",
          group: "colors",
          default: "#3f332c",
          role: "boots",
          hint: "boots color",
          affects: [
            "material"
          ],
          targets: [
            "boots"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.belt",
          label: "belt",
          kind: "color",
          group: "colors",
          default: "#4a3626",
          role: "belt",
          hint: "belt color",
          affects: [
            "material"
          ],
          targets: [
            "belt"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.hair",
          label: "hair",
          kind: "color",
          group: "colors",
          default: "#4a3427",
          role: "hair",
          hint: "hair color",
          affects: [
            "material"
          ],
          targets: [
            "hair"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "treasure-chest": {
      title: "Wooden treasure chest",
      version: "1.1.0",
      description: "A hollow oak chest with an opening faceted lid, iron bands and brass latch.",
      defaults: {
        width: 1.2,
        depth: 0.7,
        bodyHeight: 0.58,
        lidRise: 0.28,
        lidAngle: 0,
        boardCount: 4,
        bandInset: 0.2,
        latch: true,
        "color.wood": "#a86b37",
        "color.frame": "#343a3e",
        "color.brass": "#c79535"
      },
      presets: [
        {
          id: "oak",
          name: "Oak treasure chest",
          description: "Iron-bound oak chest with brass latch.",
          parameters: {}
        },
        {
          id: "small",
          name: "Open coffer",
          description: "Compact three-course coffer with its lid raised.",
          parameters: {
            width: 0.7,
            depth: 0.45,
            bodyHeight: 0.35,
            lidRise: 0.15,
            boardCount: 3,
            lidAngle: 85
          }
        },
        {
          id: "large",
          name: "Storage chest",
          description: "Broad six-course storage chest without a latch.",
          parameters: {
            width: 1.8,
            depth: 1,
            bodyHeight: 0.8,
            lidRise: 0.4,
            boardCount: 6,
            latch: false
          }
        }
      ],
      palettes: [
        {
          id: "oak",
          label: "Oak",
          colors: [
            "#a86b37",
            "#343a3e",
            "#c79535"
          ]
        }
      ],
      controls: [
        {
          key: "width",
          label: "Width",
          kind: "range",
          group: "shape",
          min: 0.7,
          max: 1.8,
          step: 0.01,
          default: 1.2,
          hint: "Outside dimension in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "base",
            "foot",
            "body",
            "end-plank",
            "lid",
            "band",
            "hinge"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "depth",
          label: "Depth",
          kind: "range",
          group: "shape",
          min: 0.45,
          max: 1,
          step: 0.01,
          default: 0.7,
          hint: "Outside dimension in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "base",
            "foot",
            "body",
            "end-plank",
            "lid",
            "band",
            "hinge",
            "latch",
            "keyhole"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "bodyHeight",
          label: "Body height",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.8,
          step: 0.01,
          default: 0.58,
          hint: "Outside dimension in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "body",
            "end-plank",
            "lid",
            "band",
            "hinge",
            "latch",
            "keyhole"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "lidRise",
          label: "Lid rise",
          kind: "range",
          group: "shape",
          min: 0.15,
          max: 0.4,
          step: 0.01,
          default: 0.28,
          hint: "Outside dimension in meters.",
          affects: [
            "geometry"
          ],
          targets: [
            "lid",
            "band-lid"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "lidAngle",
          label: "Lid opening",
          kind: "range",
          group: "construction",
          min: 0,
          max: 110,
          step: 5,
          default: 0,
          hint: "Static opening in degrees around the rear hinge. Bands and latch follow the lid.",
          affects: [
            "geometry"
          ],
          targets: [
            "lid",
            "band-lid",
            "latch",
            "keyhole"
          ],
          unit: "none",
          inputUnit: "degrees",
          displayUnit: "none"
        },
        {
          key: "boardCount",
          label: "Body courses",
          kind: "integer",
          group: "construction",
          min: 2,
          max: 6,
          step: 1,
          default: 4,
          hint: "Body courses preserve the outside height and hollow interior.",
          affects: [
            "topology"
          ],
          targets: [
            "body-plank",
            "end-plank"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "bandInset",
          label: "Band inset",
          kind: "range",
          group: "shape",
          min: 0.15,
          max: 0.3,
          step: 0.01,
          default: 0.2,
          hint: "Fraction of width from each end.",
          affects: [
            "geometry"
          ],
          targets: [
            "band",
            "hinge",
            "lid-hinge-collar"
          ],
          unit: "none",
          inputUnit: "dimensionless",
          displayUnit: "none"
        },
        {
          key: "latch",
          label: "Latch",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Adds a front brass latch.",
          affects: [
            "topology"
          ],
          targets: [
            "latch",
            "keyhole"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.wood",
          label: "wood",
          kind: "color",
          group: "colors",
          default: "#a86b37",
          role: "wood",
          hint: "Material color.",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.frame",
          label: "frame",
          kind: "color",
          group: "colors",
          default: "#343a3e",
          role: "frame",
          hint: "Material color.",
          affects: [
            "material"
          ],
          targets: [
            "frame"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.brass",
          label: "brass",
          kind: "color",
          group: "colors",
          default: "#c79535",
          role: "brass",
          hint: "Material color.",
          affects: [
            "material"
          ],
          targets: [
            "brass"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    tree: {
      title: "Broadleaf tree",
      version: "0.6.0",
      description: "Broad crowns and a supported branching silhouette.",
      defaults: {
        height: 4.5,
        spread: 3.8,
        seed: 7,
        growth: "mature",
        lean: 0.055,
        forkHeight: 0.31,
        canopyFullness: 1,
        trunkGirth: 0.22,
        branchCount: 3,
        architecture: "spreading",
        season: "summer",
        colorway: "forest",
        "color.timber": "#594739",
        "color.foliage": "#587b42",
        "color.foliageShade": "#426337",
        "color.foliageLight": "#759050"
      },
      presets: [
        {
          id: "orchard",
          name: "Spring orchard",
          description: "Spring orchard proportions",
          parameters: {
            season: "spring",
            branchCount: 3,
            canopyFullness: 0.96,
            forkHeight: 0.3,
            trunkGirth: 0.2
          }
        },
        {
          id: "young",
          name: "Slender summer sapling",
          description: "Slender summer sapling proportions",
          parameters: {
            height: 3,
            spread: 2.4,
            growth: "young",
            architecture: "upright",
            branchCount: 2,
            canopyFullness: 0.86,
            forkHeight: 0.4,
            trunkGirth: 0.15,
            lean: 0.025,
            season: "summer",
            seed: 18
          }
        },
        {
          id: "shelter",
          name: "Autumn shelter crown",
          description: "Autumn shelter crown proportions",
          parameters: {
            height: 5.3,
            spread: 5.4,
            growth: "mature",
            architecture: "spreading",
            branchCount: 4,
            canopyFullness: 1.05,
            forkHeight: 0.26,
            trunkGirth: 0.28,
            lean: -0.035,
            season: "autumn",
            seed: 91
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest",
          colors: [
            "#587b42",
            "#426337",
            "#594739"
          ]
        },
        {
          id: "harbor",
          label: "Harbor",
          colors: [
            "#587b42",
            "#426337",
            "#49524c"
          ]
        },
        {
          id: "ember",
          label: "Ember",
          colors: [
            "#587b42",
            "#426337",
            "#604234"
          ]
        }
      ],
      controls: [
        {
          kind: "range",
          key: "height",
          label: "Tree height",
          default: 4.5,
          min: 3,
          max: 6,
          step: 0.05,
          group: "shape",
          hint: "Canopy spread must be 0.55\u20131.25 \xD7 tree height. Increase spread or reduce height for a narrow crown; reduce spread or increase height for a broad crown.",
          affects: [
            "geometry"
          ],
          targets: [
            "tree"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "range",
          key: "spread",
          label: "Canopy spread",
          default: 3.8,
          min: 2.4,
          max: 5.4,
          step: 0.05,
          group: "shape",
          hint: "Canopy spread must be 0.55\u20131.25 \xD7 tree height. Increase spread or reduce height for a narrow crown; reduce spread or increase height for a broad crown.",
          affects: [
            "geometry"
          ],
          targets: [
            "tree"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          kind: "integer",
          key: "seed",
          label: "Growth seed",
          default: 7,
          min: 0,
          max: 65535,
          step: 1,
          group: "shape",
          hint: "Canopy spread must be 0.55\u20131.25 \xD7 tree height. Increase spread or reduce height for a narrow crown; reduce spread or increase height for a broad crown.",
          affects: [
            "geometry"
          ],
          targets: [
            "tree"
          ],
          unit: "seed",
          inputUnit: "integer",
          displayUnit: "seed"
        },
        {
          key: "growth",
          kind: "choice",
          group: "construction",
          label: "Growth form",
          default: "mature",
          options: [
            {
              value: "young",
              label: "Young branching"
            },
            {
              value: "mature",
              label: "Mature branching"
            }
          ],
          hint: "Changes the trunk forks and crown organization at the same height.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "trunk",
            "trunk-elbow",
            "crown-main"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "lean",
          kind: "range",
          group: "shape",
          label: "Trunk lean",
          default: 0.055,
          min: -0.1,
          max: 0.1,
          step: 5e-3,
          ratioBasis: "height",
          hint: "Crown displacement as a fraction of height; trunk and branches follow together.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "trunk",
            "trunk-elbow",
            "crown-main"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "forkHeight",
          label: "Fork height",
          kind: "range",
          default: 0.31,
          min: 0.23,
          max: 0.43,
          step: 0.01,
          ratioBasis: "height",
          group: "construction",
          hint: "Fork height reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "tree"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "canopyFullness",
          label: "Canopy fullness",
          kind: "range",
          default: 1,
          min: 0.65,
          max: 1.16,
          step: 0.01,
          ratioBasis: "normalized",
          group: "construction",
          hint: "Canopy fullness reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "tree"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "trunkGirth",
          label: "Trunk radius",
          kind: "range",
          default: 0.22,
          min: 0.12,
          max: 0.48,
          step: 0.01,
          group: "construction",
          hint: "Trunk radius in meters before taper; mature base flare is 1.45 times this radius and root wedges extend farther. Young growth uses 0.82 times this radius.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "tree"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "branchCount",
          label: "Crown branches",
          kind: "integer",
          default: 3,
          min: 2,
          max: 8,
          step: 1,
          group: "construction",
          hint: "Crown branches reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "tree"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "architecture",
          label: "Crown architecture",
          kind: "choice",
          default: "spreading",
          options: [
            {
              value: "spreading",
              label: "Spreading"
            },
            {
              value: "upright",
              label: "Upright"
            }
          ],
          group: "construction",
          hint: "Crown architecture reshapes connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "tree"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "season",
          label: "Crown season",
          default: "summer",
          options: [
            {
              value: "spring",
              label: "Spring"
            },
            {
              value: "summer",
              label: "Summer"
            },
            {
              value: "autumn",
              label: "Autumn"
            },
            {
              value: "winter",
              label: "Winter"
            }
          ],
          group: "colors",
          hint: "Select crown season.",
          affects: [
            "material"
          ],
          targets: [
            "season"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "Forest"
            },
            {
              value: "harbor",
              label: "Harbor"
            },
            {
              value: "ember",
              label: "Ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.timber",
          label: "Bark",
          role: "timber",
          default: "#594739",
          group: "colors",
          hint: "Changes only timber color.",
          affects: [
            "material"
          ],
          targets: [
            "timber"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.foliage",
          label: "Main foliage",
          role: "foliage",
          default: "#587b42",
          group: "colors",
          hint: "Changes only foliage color.",
          affects: [
            "material"
          ],
          targets: [
            "foliage"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.foliageShade",
          label: "Shaded foliage",
          role: "foliageShade",
          default: "#426337",
          group: "colors",
          hint: "Changes only foliageShade color.",
          affects: [
            "material"
          ],
          targets: [
            "foliageShade"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.foliageLight",
          label: "Upper foliage",
          role: "foliageLight",
          default: "#759050",
          group: "colors",
          hint: "Changes only foliageLight color.",
          affects: [
            "material"
          ],
          targets: [
            "foliageLight"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    wheelbarrow: {
      title: "Wooden wheelbarrow",
      version: "1.1.0",
      description: "Hollow planked tray, a single wooden wheel with iron tread and two carrying handles.",
      defaults: {
        trayWidth: 0.68,
        trayLength: 0.92,
        trayDepth: 0.3,
        wheelRadius: 0.23,
        colorway: "oak",
        boardCount: 3,
        wheelStyle: "solid",
        "color.wood": "#b58a55",
        "color.frame": "#725033",
        "color.iron": "#41464a"
      },
      presets: [
        {
          id: "farm",
          name: "Farm barrow",
          description: "Warm oak boards and dark iron tread.",
          parameters: {}
        },
        {
          id: "garden",
          name: "Garden barrow",
          description: "Compact two-course sage tray and open spoked wheel.",
          parameters: {
            trayWidth: 0.5,
            trayLength: 0.65,
            trayDepth: 0.2,
            wheelRadius: 0.16,
            colorway: "painted",
            boardCount: 2,
            wheelStyle: "spoked"
          }
        },
        {
          id: "heavy",
          name: "Heavy barrow",
          description: "Five-course tray and larger braced wheel.",
          parameters: {
            trayWidth: 0.95,
            trayLength: 1.3,
            trayDepth: 0.45,
            wheelRadius: 0.34,
            boardCount: 5
          }
        }
      ],
      palettes: [
        {
          id: "oak",
          label: "oak",
          colors: [
            "#b58a55",
            "#725033",
            "#41464a"
          ]
        },
        {
          id: "painted",
          label: "painted",
          colors: [
            "#849782",
            "#554532",
            "#343c40"
          ]
        }
      ],
      controls: [
        {
          key: "trayWidth",
          label: "Tray width",
          kind: "range",
          group: "shape",
          min: 0.5,
          max: 0.95,
          step: 0.01,
          default: 0.68,
          hint: "Tray width in meters. Frame and joints follow the selected dimensions.",
          affects: [
            "geometry"
          ],
          targets: [
            "tray",
            "floor",
            "wheel",
            "handle",
            "leg"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "trayLength",
          label: "Tray length",
          kind: "range",
          group: "shape",
          min: 0.65,
          max: 1.3,
          step: 0.01,
          default: 0.92,
          hint: "Tray length in meters. Frame and joints follow the selected dimensions.",
          affects: [
            "geometry"
          ],
          targets: [
            "tray",
            "floor",
            "wheel",
            "handle",
            "leg"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "trayDepth",
          label: "Tray depth",
          kind: "range",
          group: "shape",
          min: 0.2,
          max: 0.45,
          step: 0.01,
          default: 0.3,
          hint: "Tray depth in meters. Frame and joints follow the selected dimensions.",
          affects: [
            "geometry"
          ],
          targets: [
            "tray",
            "floor",
            "wheel",
            "handle",
            "leg"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "wheelRadius",
          label: "Wheel radius",
          kind: "range",
          group: "shape",
          min: 0.16,
          max: 0.34,
          step: 0.01,
          default: 0.23,
          hint: "Wheel radius in meters. Frame and joints follow the selected dimensions.",
          affects: [
            "geometry"
          ],
          targets: [
            "tray",
            "floor",
            "wheel",
            "handle",
            "leg"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "colorway",
          label: "Palette",
          kind: "choice",
          group: "colors",
          default: "oak",
          options: [
            {
              value: "oak",
              label: "Oak"
            },
            {
              value: "painted",
              label: "Sage"
            }
          ],
          hint: "Wood and iron palette.",
          affects: [
            "material"
          ],
          targets: [
            "wood",
            "frame",
            "iron"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "boardCount",
          label: "Tray courses",
          kind: "integer",
          group: "construction",
          min: 2,
          max: 5,
          step: 1,
          default: 3,
          hint: "Changes wall courses while preserving the floor, rim and outside height.",
          affects: [
            "topology"
          ],
          targets: [
            "tray-side",
            "tray-end"
          ],
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          key: "wheelStyle",
          label: "Wheel construction",
          kind: "choice",
          group: "construction",
          default: "solid",
          options: [
            {
              value: "solid",
              label: "Braced solid wheel"
            },
            {
              value: "spoked",
              label: "Open spoked wheel"
            }
          ],
          hint: "Solid wooden disks or an open rim with twelve spokes and a hub.",
          affects: [
            "topology"
          ],
          targets: [
            "wheel-tread",
            "wheel-wood",
            "wheel-rim",
            "wheel-spoke",
            "wheel-hub"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.wood",
          label: "wood",
          kind: "color",
          group: "colors",
          default: "#b58a55",
          role: "wood",
          hint: "Color of wood parts.",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.frame",
          label: "frame",
          kind: "color",
          group: "colors",
          default: "#725033",
          role: "frame",
          hint: "Color of frame parts.",
          affects: [
            "material"
          ],
          targets: [
            "frame"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.iron",
          label: "iron",
          kind: "color",
          group: "colors",
          default: "#41464a",
          role: "iron",
          hint: "Color of iron parts.",
          affects: [
            "material"
          ],
          targets: [
            "iron"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    windmill: {
      title: "Windmill",
      version: "2.0.0",
      description: "A working windmill with lattice sails: a post mill on a trestle, an eight-sided smock mill or a round stone tower mill.",
      defaults: {
        form: "post",
        height: 8,
        sailLength: 0.48,
        sailTurn: 0.055,
        cloth: true,
        "color.wall": "#8a6a4a",
        "color.roof": "#4e4a48",
        "color.wood": "#5a4330",
        "color.cloth": "#e6dcc4",
        "color.stone": "#9a948a"
      },
      presets: [
        {
          id: "post",
          name: "Post mill",
          description: "Timber buck on a trestle with a ladder and tail pole.",
          parameters: {}
        },
        {
          id: "smock",
          name: "Smock mill",
          description: "Eight-sided timber smock on a brick base with a stage.",
          parameters: {
            form: "smock",
            height: 9,
            "color.wall": "#e8e2d2",
            "color.roof": "#3e5a4a",
            sailTurn: 0.1
          }
        },
        {
          id: "tower",
          name: "Tower mill",
          description: "Round stone tower with a conical cap.",
          parameters: {
            form: "tower",
            height: 10,
            "color.roof": "#3f3a38",
            sailTurn: 0.03
          }
        }
      ],
      palettes: [],
      controls: [
        {
          key: "form",
          label: "Mill type",
          kind: "choice",
          group: "construction",
          default: "post",
          options: [
            {
              value: "post",
              label: "Post mill"
            },
            {
              value: "smock",
              label: "Smock mill"
            },
            {
              value: "tower",
              label: "Tower mill"
            }
          ],
          hint: "Timber post mill on a trestle, eight-sided smock, or round stone tower.",
          affects: [
            "topology"
          ],
          targets: [
            "body"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "height",
          label: "Body height",
          kind: "range",
          group: "shape",
          min: 5,
          max: 14,
          step: 0.1,
          default: 8,
          hint: "Height to the top of the cap.",
          affects: [
            "geometry"
          ],
          targets: [
            "body"
          ],
          unit: "m",
          inputUnit: "m",
          displayUnit: "m"
        },
        {
          key: "sailLength",
          label: "Sail length",
          kind: "range",
          group: "shape",
          min: 0.35,
          max: 0.6,
          step: 0.01,
          default: 0.48,
          hint: "Sail length relative to height.",
          affects: [
            "geometry"
          ],
          targets: [
            "sails"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "sailTurn",
          label: "Sail turn",
          kind: "range",
          group: "shape",
          min: 0,
          max: 0.25,
          step: 5e-3,
          default: 0.055,
          hint: "Rotation of the sails.",
          affects: [
            "geometry"
          ],
          targets: [
            "sails"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          key: "cloth",
          label: "Sail cloth",
          kind: "toggle",
          group: "construction",
          default: true,
          hint: "Cloth spread on the lattice.",
          affects: [
            "geometry"
          ],
          targets: [
            "sails"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          key: "color.wall",
          label: "wall",
          kind: "color",
          group: "colors",
          default: "#8a6a4a",
          role: "wall",
          hint: "wall color",
          affects: [
            "material"
          ],
          targets: [
            "wall"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.roof",
          label: "roof",
          kind: "color",
          group: "colors",
          default: "#4e4a48",
          role: "roof",
          hint: "roof color",
          affects: [
            "material"
          ],
          targets: [
            "roof"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.wood",
          label: "wood",
          kind: "color",
          group: "colors",
          default: "#5a4330",
          role: "wood",
          hint: "wood color",
          affects: [
            "material"
          ],
          targets: [
            "wood"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.cloth",
          label: "cloth",
          kind: "color",
          group: "colors",
          default: "#e6dcc4",
          role: "cloth",
          hint: "cloth color",
          affects: [
            "material"
          ],
          targets: [
            "cloth"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          key: "color.stone",
          label: "stone",
          kind: "color",
          group: "colors",
          default: "#9a948a",
          role: "stone",
          hint: "stone color",
          affects: [
            "material"
          ],
          targets: [
            "stone"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        }
      ]
    },
    "work-lantern": {
      title: "Work lantern",
      version: "0.6.0",
      description: "A rustic vessel or utility light with adjustable hood and carry hoop.",
      defaults: {
        bodyWidth: 0.32,
        bodyHeight: 0.26,
        handleClearance: 0.115,
        frameWeight: "heavy",
        guardLayout: "sparse",
        detail: "inspection",
        colorway: "forest",
        "color.body": "#526750",
        "color.enclosure": "#eee1bf",
        "color.structure": "#303b35",
        "color.accent": "#d2a449",
        enclosureProfile: "octagonal",
        hoodFlare: 0.18,
        handleProfile: "arched",
        guardCount: 4,
        construction: "rustic",
        hoodRise: 1,
        carryHoop: "oval"
      },
      presets: [
        {
          id: "field",
          name: "Rustic field lantern",
          description: "Octagonal oil vessel, oval hoop and raised cap",
          parameters: {
            bodyWidth: 0.32,
            bodyHeight: 0.26,
            handleClearance: 0.115,
            colorway: "forest",
            construction: "rustic",
            hoodRise: 1.1,
            carryHoop: "oval",
            guardCount: 4
          }
        },
        {
          id: "harbor",
          name: "Harbor utility lamp",
          description: "Broad utility housing and square carry band",
          parameters: {
            bodyWidth: 0.4,
            bodyHeight: 0.235,
            handleClearance: 0.13,
            colorway: "harbor",
            construction: "utility",
            enclosureProfile: "square",
            hoodFlare: 0.22,
            handleProfile: "square",
            guardCount: 4
          }
        },
        {
          id: "trail",
          name: "Tall trail oil lantern",
          description: "Narrow reservoir and tall carry hoop",
          parameters: {
            bodyWidth: 0.24,
            bodyHeight: 0.285,
            handleClearance: 0.14,
            colorway: "ember",
            construction: "rustic",
            enclosureProfile: "octagonal",
            hoodFlare: 0.1,
            hoodRise: 1.2,
            carryHoop: "tall",
            guardCount: 6,
            frameWeight: "light"
          }
        }
      ],
      palettes: [
        {
          id: "forest",
          label: "Forest & cream",
          colors: [
            "#526750",
            "#eee1bf",
            "#303b35"
          ]
        },
        {
          id: "harbor",
          label: "Harbor & chalk",
          colors: [
            "#3e777b",
            "#e9e4d3",
            "#293b43"
          ]
        },
        {
          id: "ember",
          label: "Ember & sand",
          colors: [
            "#ad6149",
            "#f0ddba",
            "#4b3933"
          ]
        }
      ],
      controls: [
        {
          key: "bodyWidth",
          label: "Body width",
          min: 0.22,
          max: 0.44,
          step: 1e-3,
          hint: "Widens the enclosure, hood and base together.",
          kind: "range",
          default: 0.32,
          group: "shape",
          affects: [
            "geometry"
          ],
          targets: [
            "enclosure",
            "hood",
            "base",
            "handle"
          ],
          unit: "cm",
          inputUnit: "m",
          displayUnit: "cm"
        },
        {
          key: "bodyHeight",
          label: "Body height",
          min: 0.18,
          max: 0.36,
          step: 1e-3,
          hint: "Enclosure only, excluding the hood and handle.",
          kind: "range",
          default: 0.26,
          group: "shape",
          affects: [
            "geometry"
          ],
          targets: [
            "enclosure",
            "hood",
            "base",
            "handle"
          ],
          unit: "cm",
          inputUnit: "m",
          displayUnit: "cm"
        },
        {
          key: "handleClearance",
          label: "Handle opening",
          min: 0.075,
          max: 0.19,
          step: 1e-3,
          hint: "Clear space above the hood, beneath the grip.",
          kind: "range",
          default: 0.115,
          group: "shape",
          affects: [
            "geometry"
          ],
          targets: [
            "enclosure",
            "hood",
            "base",
            "handle"
          ],
          unit: "cm",
          inputUnit: "m",
          displayUnit: "cm"
        },
        {
          kind: "choice",
          key: "frameWeight",
          label: "Frame weight",
          default: "heavy",
          options: [
            {
              value: "light",
              label: "light"
            },
            {
              value: "heavy",
              label: "heavy"
            }
          ],
          group: "construction",
          hint: "Select frame weight.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "frameWeight"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "guardLayout",
          label: "Guard layout",
          default: "sparse",
          options: [
            {
              value: "sparse",
              label: "sparse"
            },
            {
              value: "crossbar",
              label: "crossbar"
            }
          ],
          group: "construction",
          hint: "Select guard layout.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "guardLayout"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "detail",
          label: "Detail",
          default: "inspection",
          options: [
            {
              value: "scene",
              label: "scene"
            },
            {
              value: "inspection",
              label: "inspection"
            }
          ],
          group: "construction",
          hint: "Select detail.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "detail"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "choice",
          key: "colorway",
          label: "Colorway",
          default: "forest",
          options: [
            {
              value: "forest",
              label: "forest"
            },
            {
              value: "harbor",
              label: "harbor"
            },
            {
              value: "ember",
              label: "ember"
            }
          ],
          group: "colors",
          hint: "Select colorway.",
          affects: [
            "material"
          ],
          targets: [
            "colorway"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "color",
          key: "color.body",
          label: "body",
          role: "body",
          default: "#526750",
          group: "colors",
          hint: "Changes only body color.",
          affects: [
            "material"
          ],
          targets: [
            "body"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.enclosure",
          label: "enclosure",
          role: "enclosure",
          default: "#eee1bf",
          group: "colors",
          hint: "Changes only enclosure color.",
          affects: [
            "material"
          ],
          targets: [
            "enclosure"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.structure",
          label: "structure",
          role: "structure",
          default: "#303b35",
          group: "colors",
          hint: "Changes only structure color.",
          affects: [
            "material"
          ],
          targets: [
            "structure"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "color",
          key: "color.accent",
          label: "accent",
          role: "accent",
          default: "#d2a449",
          group: "colors",
          hint: "Changes only accent color.",
          affects: [
            "material"
          ],
          targets: [
            "accent"
          ],
          unit: "color",
          inputUnit: "color",
          displayUnit: "color"
        },
        {
          kind: "choice",
          default: "octagonal",
          options: [
            {
              value: "square",
              label: "Square"
            },
            {
              value: "octagonal",
              label: "Octagonal"
            }
          ],
          key: "enclosureProfile",
          label: "Enclosure profile",
          group: "construction",
          hint: "Changes the light housing and retaining frames to square or eight-sided sections; guards follow the profile.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "enclosure",
            "lower-frame",
            "upper-frame",
            "guard-upright-*"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          ratioBasis: "width",
          default: 0.18,
          min: 0.08,
          max: 0.3,
          step: 0.01,
          key: "hoodFlare",
          label: "Hood flare",
          group: "construction",
          hint: "Adds this fraction of body width to each hood side; the top collar stays fitted.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "hood"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          default: "arched",
          options: [
            {
              value: "arched",
              label: "Arched"
            },
            {
              value: "square",
              label: "Square"
            }
          ],
          key: "handleProfile",
          label: "Carry handle",
          group: "construction",
          hint: "Chooses a curved tubular carry hoop or a square band while keeping the requested clear height.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "handle"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "integer",
          default: 4,
          min: 3,
          max: 6,
          key: "guardCount",
          label: "Guard count",
          group: "construction",
          hint: "Distributes three to six tapered vertical guards around the enclosure.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "guard-upright-*"
          ],
          step: 1,
          unit: "count",
          inputUnit: "integer",
          displayUnit: "count"
        },
        {
          kind: "choice",
          key: "construction",
          label: "Lantern construction",
          default: "rustic",
          options: [
            {
              value: "rustic",
              label: "Rustic oil lantern"
            },
            {
              value: "utility",
              label: "Utility lamp"
            }
          ],
          group: "construction",
          hint: "Rebuilds reservoir, vessel and ventilated cap as a connected construction.",
          affects: [
            "geometry",
            "topology"
          ],
          targets: [
            "oil-reservoir",
            "enclosure",
            "hood",
            "handle"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        },
        {
          kind: "range",
          key: "hoodRise",
          label: "Cap rise",
          default: 1,
          min: 0.75,
          max: 1.25,
          step: 0.05,
          group: "construction",
          ratioBasis: "normalized",
          hint: "Raises the cap, vents and carry seats together.",
          affects: [
            "geometry"
          ],
          targets: [
            "hood",
            "vented-cap",
            "handle"
          ],
          unit: "ratio",
          inputUnit: "dimensionless",
          displayUnit: "ratio"
        },
        {
          kind: "choice",
          key: "carryHoop",
          label: "Rustic carry hoop",
          default: "oval",
          options: [
            {
              value: "oval",
              label: "Oval"
            },
            {
              value: "round",
              label: "Round"
            },
            {
              value: "tall",
              label: "Tall oval"
            }
          ],
          group: "construction",
          hint: "Changes the rustic hoop aspect while retaining its mountings.",
          affects: [
            "geometry"
          ],
          targets: [
            "handle"
          ],
          unit: "none",
          inputUnit: "none",
          displayUnit: "none"
        }
      ]
    }
  }
};

// src/formats/controls.ts
var hex = (v) => Math.round(Math.min(1, Math.max(0, v <= 31308e-7 ? v * 12.92 : 1.055 * v ** (1 / 2.4) - 0.055)) * 255).toString(16).padStart(2, "0");
function familyControls(id) {
  return model_controls_default.families[id] ?? null;
}
function controlsDocument({ design, glb, title }) {
  const family = design?.family ? familyControls(design.family) : null, applied = design?.applied ?? {};
  let materials = [], size = null;
  if (glb) {
    const scene = readGlb(glb), b = bounds(scene);
    materials = scene.materials.filter((_, i) => scene.meshes.some((m) => m.material === i)).map((m) => ({ name: m.name, baseColor: m.color, hex: "#" + hex(m.color[0]) + hex(m.color[1]) + hex(m.color[2]), metallic: m.metallic, roughness: m.roughness }));
    size = { min: b.min, max: b.max, dimensions: b.max.map((v, i) => v - b.min[i]) };
  }
  return {
    formatVersion: 1,
    kind: "polyspoon.model-controls",
    title: title ?? family?.title ?? design?.family ?? null,
    family: design?.family ?? null,
    familyVersion: design?.familyVersion ?? null,
    recipeVersion: family?.version ?? null,
    units: model_controls_default.units,
    parameters: (family?.controls ?? []).map((control) => ({ ...control, value: Object.hasOwn(applied, control.key) ? applied[control.key] : control.default })),
    applied,
    appearance: design?.appearance ?? null,
    presets: family?.presets ?? [],
    palettes: family?.palettes ?? [],
    materials,
    bounds: size,
    formats: ["glb", ...Object.keys(exportFormats)],
    note: family ? "Change parameters in the Polyspoon editor or with the agent toolkit, then export again; downloaded meshes are static snapshots." : "This recipe is not a built-in family, so knob metadata is not listed; applied values are the exact saved design."
  };
}
export {
  controlsDocument,
  convertGlb,
  exportFormats,
  familyControls
};
